[CmdletBinding()]
param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($env:OS -ne 'Windows_NT') { throw 'This build must run on Windows x64.' }
$Root = Split-Path $PSScriptRoot -Parent
Push-Location $Root
try {
    & $Python -c "import sys,struct; assert sys.version_info[:2] == (3,12), 'Python 3.12 required'; assert struct.calcsize('P') == 8, '64-bit Python required'"
    if ($LASTEXITCODE -ne 0) { throw 'Unsupported Python build environment.' }
    & $Python -m venv .venv-build
    if ($LASTEXITCODE -ne 0) { throw 'Could not create build environment.' }
    $BuildPython = Join-Path $Root '.venv-build/Scripts/python.exe'
    & $BuildPython -m pip install --disable-pip-version-check -r requirements-build.txt
    if ($LASTEXITCODE -ne 0) { throw 'Build dependencies could not be installed.' }
    # Dictionary rebuild is fully offline, from bundled, SHA-verified source data.
    & $BuildPython tools/build_dictionary.py
    if ($LASTEXITCODE -ne 0) { throw 'Dictionary integrity/build failed.' }
    New-Item -ItemType Directory -Force 'release' | Out-Null
    $OldQtPlatform = $env:QT_QPA_PLATFORM
    $env:QT_QPA_PLATFORM = 'offscreen'
    try {
        & $BuildPython -m pytest tests -q --junitxml=release/unit-tests.xml
        if ($LASTEXITCODE -ne 0) { throw 'Automated tests failed. No release produced.' }
        & $BuildPython -m PyInstaller --noconfirm --clean PepperBeanJournal.spec
        if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }
        $Exe = Join-Path $Root 'dist/PepperBeanJournal/PepperBeanJournal.exe'
        if (-not (Test-Path $Exe)) { throw 'Expected Windows executable was not produced.' }
        $Report = Join-Path $Root 'release/windows-packaged-self-test.json'
        if (Test-Path $Report) { Remove-Item $Report -Force }
        # Start-Process -Wait is required for GUI executables; '&' may not wait.
        $Process = Start-Process -FilePath $Exe -ArgumentList @('--self-test', '--report', ('"' + $Report + '"')) -Wait -PassThru
        if ($Process.ExitCode -ne 0) { throw "Packaged self-test failed with exit code $($Process.ExitCode)." }
        if (-not (Test-Path $Report)) { throw 'Packaged executable did not produce its test report.' }
        $Results = Get-Content $Report -Raw | ConvertFrom-Json
        if ($Results.passed -ne $true) { throw 'Packaged report did not confirm success.' }
    } finally {
        if ($null -eq $OldQtPlatform) { Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue }
        else { $env:QT_QPA_PLATFORM = $OldQtPlatform }
    }
    $Portable = Join-Path $Root 'dist/PepperBeanJournal'
    Copy-Item 'docs' (Join-Path $Portable 'docs') -Recurse -Force
    foreach ($Name in @('README.md', 'THIRD_PARTY.md', 'LICENSE', 'LICENSE.txt', 'LICENSES')) {
        if (Test-Path $Name) { Copy-Item $Name (Join-Path $Portable $Name) -Recurse -Force }
    }
    New-Item -ItemType Directory -Force (Join-Path $Portable 'LICENSES') | Out-Null
    & $BuildPython -c "import pathlib,sys,shutil; p=pathlib.Path(sys.base_prefix)/'LICENSE.txt'; assert p.is_file(), 'Python runtime license missing'; shutil.copy2(p, 'dist/PepperBeanJournal/LICENSES/Python-runtime-LICENSE.txt')"
    if ($LASTEXITCODE -ne 0) { throw 'Python runtime license copy failed.' }
    Copy-Item 'release/windows-packaged-self-test.json' $Portable -Force
    Copy-Item 'docs/PORTABLE_README.md' (Join-Path $Portable 'README.md') -Force
    # Corresponding application/vendor/data sources accompany the binary.
    # Exclude caches, virtualenvs, dist and the generated dictionary, which is
    # reproducible from the compact licensed source included below.
    $SourceTemp = Join-Path $Root 'release/source-staging'
    if (Test-Path $SourceTemp) { Remove-Item $SourceTemp -Recurse -Force }
    New-Item -ItemType Directory -Force $SourceTemp | Out-Null
    foreach ($Name in @('pepperbean', 'vendor', 'tools', 'tests', 'docs', '.github', 'LICENSES')) {
        if (Test-Path $Name) { Copy-Item $Name (Join-Path $SourceTemp $Name) -Recurse -Force }
    }
    New-Item -ItemType Directory -Force (Join-Path $SourceTemp 'assets') | Out-Null
    Copy-Item 'assets/dictionary_sources' (Join-Path $SourceTemp 'assets/dictionary_sources') -Recurse -Force
    Copy-Item 'assets/icon.*' (Join-Path $SourceTemp 'assets') -Force
    foreach ($Name in @('run.py', 'README.md', 'THIRD_PARTY.md', 'LICENSE', 'LICENSE.txt', 'requirements-build.txt', 'PepperBeanJournal.spec', 'pytest.ini', 'pyproject.toml', '.gitignore')) {
        if (Test-Path $Name) { Copy-Item $Name $SourceTemp -Force }
    }
    Get-ChildItem $SourceTemp -Directory -Recurse -Force | Where-Object { $_.Name -in @('__pycache__', '.pytest_cache') } | Sort-Object FullName -Descending | Remove-Item -Recurse -Force
    # Python zipfile includes dot-directories such as .github on Windows.
    & $BuildPython -c "import pathlib,zipfile; r=pathlib.Path('release/source-staging'); z=zipfile.ZipFile('dist/PepperBeanJournal/Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6); [z.write(p,p.relative_to(r)) for p in sorted(r.rglob('*')) if p.is_file()]; z.close()"
    if ($LASTEXITCODE -ne 0) { throw 'Source archive failed.' }
    & $BuildPython -c "import pathlib,zipfile; r=pathlib.Path('dist'); z=zipfile.ZipFile('release/PepperBeanJournal-Windows-x64.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6); [z.write(p,p.relative_to(r)) for p in sorted((r/'PepperBeanJournal').rglob('*')) if p.is_file()]; z.close()"
    if ($LASTEXITCODE -ne 0) { throw 'Portable ZIP creation failed.' }
    Get-FileHash 'release/PepperBeanJournal-Windows-x64.zip' -Algorithm SHA256 | Format-List
    Write-Host 'Built release/PepperBeanJournal-Windows-x64.zip. Clean Windows 11 manual testing is still required.'
} finally {
    Pop-Location
}
