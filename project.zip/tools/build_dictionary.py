"""Build the offline dictionary, without network, from bundled licensed sources.

All textual meanings/examples come from the cited sources, not generated text.
Run from any directory: python tools/build_dictionary.py
"""
from __future__ import annotations
import gzip
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import unicodedata
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'assets' / 'dictionary_sources'
OUT = ROOT / 'assets' / 'dictionary.sqlite3'
NS = {'t': 'http://www.tei-c.org/ns/1.0'}


def key(text):
    return unicodedata.normalize('NFC', text).replace('’', "'").strip().casefold()


def english_keys(gloss):
    """Index only short simple equivalents; keep the complete gloss on each row.

    This is a reverse lookup in English glosses, not an EN Wiktionary dataset.
    Longer explanatory definitions remain available in French-to-English mode.
    """
    # Parenthetical explanation is context, not part of the lookup word.
    # Reject unmatched/nested markup instead of guessing its interpretation.
    simple=re.sub(r"\([^()]*\)", "", gloss).strip().rstrip('.')
    if any(c in simple for c in '():.[]!?/“”"'):
        return []
    candidates=[]
    for equivalent in re.split(r'[,;]', simple):
        value=key(equivalent)
        for prefix in ('to ', 'a ', 'an '):
            if value.startswith(prefix):
                value=value[len(prefix):]
                break
        # If a list contains an explanatory clause, reject the entire gloss;
        # do not turn an embedded word (e.g. breakfast in half-board) into a meaning.
        if (not value or len(value.split()) > 4 or len(value)>65
                or any(w in value.split() for w in ('of','that','which','someone','something','with','who','and'))):
            return []
        candidates.append(value)
    return list(dict.fromkeys(candidates))


def compact_kaikki(source, destination):
    """Audit/reproduce the field reduction from an original Kaikki JSONL.

    Quotations are excluded; only type=example without external reference is kept.
    The compact data remain licensed CC BY-SA 4.0. This function does not download
    anything or silently change the trusted manifest. Packaging uses the bundled
    compact source whose checksum is verified by main().
    """
    import io
    with open(source, encoding='utf-8') as src, open(destination,'wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
            with io.TextIOWrapper(gz,encoding='utf-8',newline='\n') as dst:
                for line in src:
                    x=json.loads(line)
                    y={k:v for k,v in x.items() if k in {'word','pos','lang_code','tags'}}
                    y['forms']=[{'form':f['form'],'tags':f.get('tags',[])} for f in x.get('forms',[]) if f.get('form') and not set(f.get('tags',[]))&{'table-tags','inflection-template','multiword-construction','romanization'}]
                    y['senses']=[]
                    for sense in x.get('senses',[]):
                        item={k:v for k,v in sense.items() if k in {'glosses','tags','form_of','alt_of','id'}}
                        item['examples']=[{k:v for k,v in example.items() if k in {'text','translation','english','type'}} for example in sense.get('examples',[]) if example.get('type')=='example' and not example.get('ref')]
                        y['senses'].append(item)
                    dst.write(json.dumps(y,ensure_ascii=False,separators=(',',':'))+'\n')


def main():
    manifest = json.loads((SOURCES / 'manifest.json').read_text())
    for name, expected in manifest['files'].items():
        with (SOURCES / name).open('rb') as source:
            actual = hashlib.file_digest(source, 'sha256').hexdigest()
        if actual != expected:
            raise ValueError(f'Source checksum mismatch: {name}')
    tmp = OUT.with_suffix('.building')
    tmp.unlink(missing_ok=True)
    db = sqlite3.connect(tmp)
    db.executescript('''
        PRAGMA journal_mode=OFF;
        CREATE TABLE entries (
          id INTEGER PRIMARY KEY, direction TEXT NOT NULL, lookup_key TEXT NOT NULL,
          word TEXT NOT NULL, translation TEXT NOT NULL, pos TEXT NOT NULL,
          gender TEXT NOT NULL, example TEXT NOT NULL, example_translation TEXT NOT NULL,
          source TEXT NOT NULL, lemma TEXT NOT NULL, verb_group TEXT NOT NULL,
          definition TEXT NOT NULL, match_kind TEXT NOT NULL, priority INTEGER NOT NULL);
        CREATE TABLE forms (form TEXT NOT NULL, lemma TEXT NOT NULL, PRIMARY KEY(form,lemma)) WITHOUT ROWID;
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    ''')
    insert = 'INSERT INTO entries VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    counts = {'kaikki_source_records':0, 'kaikki_senses':0, 'freedict_en_fr_headwords':0, 'freedict_fr_en_headwords':0}
    with gzip.open(SOURCES/'kaikki-fr-compact.jsonl.gz','rt',encoding='utf-8') as stream:
        for line in stream:
            x=json.loads(line)
            if x.get('lang_code') != 'fr':
                continue
            counts['kaikki_source_records'] += 1
            word, pos=x['word'],x.get('pos','')
            wiki='Wiktionary contributors / Kaikki (CC BY-SA 4.0) — https://en.wiktionary.org/wiki/'+word.replace(' ', '_')+'#French'
            senses=x.get('senses',[])
            lexical_senses=[s for s in senses if not s.get('form_of') and not s.get('alt_of')]
            if lexical_senses:
                for form in x.get('forms',[]):
                    spelling=form.get('form','')
                    if spelling and spelling not in ('—','-') and key(spelling)!=key(word):
                        db.execute('INSERT OR IGNORE INTO forms VALUES (?,?)',(key(spelling),key(word)))
            for sense in senses:
                for lemma in sense.get('form_of',[])+sense.get('alt_of',[]):
                    if lemma.get('word') and key(lemma['word']) != key(word):
                        db.execute('INSERT OR IGNORE INTO forms VALUES (?,?)',(key(word),key(lemma['word'])))
                # Avoid pretending "plural of ..." is an English meaning. Resolve the lemma at lookup.
                if sense.get('form_of') or sense.get('alt_of'):
                    continue
                glosses=sense.get('glosses',[])
                if not glosses:
                    continue
                gloss='; '.join(glosses)
                tags=set(x.get('tags',[])+sense.get('tags',[]))
                gender='/'.join(t for t in ('masculine','feminine','neuter') if t in tags)
                usage=', '.join(sorted(tags-{'masculine','feminine','neuter'}))
                context_gloss=('['+usage+'] ' if usage else '')+gloss
                examples=sense.get('examples',[])
                example=next((e for e in examples if e.get('text') and (e.get('translation') or e.get('english'))),None)
                example=example or next((e for e in examples if e.get('text')), {})
                extext=example.get('text',''); extrans=example.get('translation',example.get('english',''))
                db.execute(insert,('fr-en',key(word),word,context_gloss,pos,gender,extext,extrans,wiki,word,'',context_gloss,'headword',1))
                counts['kaikki_senses']+=1
                for gloss_part in glosses:
                    for en in english_keys(gloss_part):
                        db.execute(insert,('en-fr',en,en,word,pos,gender,extext,extrans,wiki+' [reverse English gloss]',word,'',context_gloss,'reverse-gloss',1))
    db.execute('CREATE INDEX temporary_enrichment ON entries(direction,lookup_key,translation)')
    for filename,direction,countkey in [('eng-fra.tei','en-fr','freedict_en_fr_headwords'),('fra-eng.tei','fr-en','freedict_fr_en_headwords')]:
        root=ET.parse(SOURCES/filename).getroot()
        entries=root.findall('.//t:entry',NS)
        counts[countkey]=len(entries)
        for e in entries:
            word=e.findtext('t:form/t:orth','',NS).strip()
            if not word:continue
            pos=e.findtext('t:gramGrp/t:pos','',NS).strip()
            gender=e.findtext('t:gramGrp/t:gen','',NS).strip()
            for sense in e.findall('t:sense',NS):
                for node in sense.findall('.//t:cit[@type="trans"]/t:quote',NS):
                    translation=''.join(node.itertext()).strip()
                    if not translation:continue
                    source=f'FreeDict {filename.removesuffix(".tei")} (GPL-2.0-or-later) — https://freedict.org/'
                    # English source POS does not imply French target gender/POS.
                    fields=(pos,gender) if direction=='fr-en' else ('','')
                    lemma=word if direction=='fr-en' else translation
                    extext=extrans=''
                    definition=word if direction=='en-fr' else translation
                    if direction=='en-fr':
                        extra=db.execute("SELECT pos,gender,example,example_translation,definition,source FROM entries WHERE direction='en-fr' AND lookup_key=? AND translation=? LIMIT 1",(key(word),translation)).fetchone()
                        if extra:
                            fields=extra[:2];extext,extrans,definition=extra[2:5]
                            source+='; metadata/example: '+extra[5]
                    db.execute(insert,(direction,key(word),word,translation,*fields,extext,extrans,source,lemma,'',definition,'headword',0 if direction=='en-fr' else 2))
                    if direction=='fr-en':
                        # Reverse the actual equivalent; no generated or split meanings.
                        en=key(translation)
                        if en.startswith('to '):en=en[3:]
                        db.execute(insert,('en-fr',en,en,word,pos,gender,'','',source+' [reverse translation]',word,'',translation,'reverse-translation',2))
    db.executescript('''
        DROP INDEX temporary_enrichment;
        CREATE INDEX entries_lookup ON entries(direction,lookup_key,priority);
        CREATE INDEX entries_lemma ON entries(direction,lemma);
    ''')
    for direction in ('en-fr','fr-en'):
        counts[direction+'_keys']=db.execute('SELECT COUNT(DISTINCT lookup_key) FROM entries WHERE direction=?',(direction,)).fetchone()[0]
        counts[direction+'_records']=db.execute('SELECT COUNT(*) FROM entries WHERE direction=?',(direction,)).fetchone()[0]
    counts['inflected_form_lemma_pairs']=db.execute('SELECT COUNT(*) FROM forms').fetchone()[0]
    counts['distinct_inflected_forms']=db.execute('SELECT COUNT(DISTINCT form) FROM forms').fetchone()[0]
    for k,v in counts.items():db.execute('INSERT INTO metadata VALUES (?,?)',(k,str(v)))
    db.execute('INSERT INTO metadata VALUES (?,?)',('schema_version','1'))
    db.commit()
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    db.execute('VACUUM');db.close()
    tmp.replace(OUT)
    (SOURCES/'coverage.json').write_text(json.dumps(counts,indent=2)+'\n')
    print(json.dumps(counts,indent=2)); print('Database bytes:',OUT.stat().st_size)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compact-from',type=Path)
    parser.add_argument('--compact-output',type=Path)
    args=parser.parse_args()
    if args.compact_from:
        if not args.compact_output:
            parser.error('--compact-from requires --compact-output')
        compact_kaikki(args.compact_from,args.compact_output)
    else:
        main()
