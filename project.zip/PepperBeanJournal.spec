# -*- mode: python ; coding: utf-8 -*-
"""Build on Windows x64 with Python 3.12. No cross-compilation claim."""
from pathlib import Path
import sys
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

root = Path(SPECPATH)
sys.path.insert(0, str(root / 'vendor'))
# Grammalecte discovers French modules dynamically. Analyze those modules too,
# while keeping original source and dictionary JSONs available for pkgutil.
grammar_modules = collect_submodules(
    'grammalecte',
    filter=lambda name: not any(part in name for part in ('tests_', '.bottle')),
)
grammar_data = collect_data_files('grammalecte', include_py_files=False)
data = [
    (str(root / 'assets' / 'dictionary.sqlite3'), 'assets'),
    (str(root / 'assets' / 'icon.svg'), 'assets'),
    (str(root / 'vendor'), 'vendor'),
    (str(root / 'docs'), 'docs'),
]
for name in ('LICENSE', 'LICENSE.txt', 'THIRD_PARTY.md', 'README.md', 'LICENSES'):
    if (root / name).exists():
        data.append((str(root / name), name if (root / name).is_dir() else '.'))
data += grammar_data

a = Analysis(
    [str(root / 'run.py')],
    pathex=[str(root), str(root / 'vendor')],
    binaries=[],
    datas=data,
    hiddenimports=grammar_modules + ['PySide6.QtSvg'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'PyQt5', 'PyQt6', 'PySide2'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='PepperBeanJournal',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon=str(root / 'assets' / 'icon.ico'),
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name='PepperBeanJournal',
)
