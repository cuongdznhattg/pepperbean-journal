from __future__ import annotations

from datetime import datetime
from html import escape
from pathlib import Path
import re

from PySide6.QtCore import Qt, QDate, QTimer, Signal, QThread, QSignalBlocker
from PySide6.QtGui import QIcon, QTextCursor, QTextCharFormat, QColor, QAction, QKeySequence
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QLineEdit, QDateEdit, QListWidget, QListWidgetItem,
    QTextBrowser, QComboBox, QSplitter, QStackedWidget, QFileDialog, QGridLayout,
    QMessageBox, QDialog, QDialogButtonBox, QTextEdit,
)

from .paths import ASSETS
from .storage import Store, atomic_write
from .dictionary import Dictionary
from .grammar import FrenchChecker
from .theme import STYLE


def utf16_position(text, offset):
    """Qt cursor positions use UTF-16; Python and Grammalecte use code points."""
    return len(text[:offset].encode('utf-16-le')) // 2


def button(text, callback, primary=False):
    b = QPushButton(text)
    if primary:
        b.setObjectName('Primary')
    b.clicked.connect(callback)
    return b


def label(text, kind='Muted'):
    w = QLabel(text)
    w.setObjectName(kind)
    w.setWordWrap(True)
    return w


def definition_html(r):
    parts = [f'<h2>{escape(r.get("word", ""))}</h2>',
             f'<p><b>{escape(r.get("translation", ""))}</b></p>']
    fields = [('lemma', 'Nguyên mẫu / từ gốc'), ('pos', 'Từ loại'), ('gender', 'Giống'),
              ('group', 'Nhóm động từ'), ('definition', 'Định nghĩa gốc / ngữ cảnh nghĩa'), ('match_kind', 'Loại kết quả'), ('example', 'Ví dụ'),
              ('example_translation', 'Nghĩa ví dụ'), ('source', 'Nguồn')]
    for key, title in fields:
        if r.get(key):
            value = r[key]
            if key == 'match_kind':
                value = {'headword': 'Mục dịch trực tiếp', 'reverse-gloss': 'Tra ngược định nghĩa — đọc ngữ cảnh nghĩa', 'inflected-form': 'Tìm từ gốc qua dạng biến đổi', 'reverse-translation': 'Tra ngược mục dịch FreeDict'}.get(value, value)
            parts.append(f'<p><b>{title}:</b> {escape(str(value))}</p>')
    return ''.join(parts)


class JournalEditor(QPlainTextEdit):
    word_lookup = Signal(str)

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        word = self.textCursor().selectedText().strip()
        if word:
            self.word_lookup.emit(word)


class CheckWorker(QThread):
    result = Signal(object, str, str)
    failed = Signal(str)

    def __init__(self, checker, text, day, parent=None):
        super().__init__(parent)
        self.checker, self.text, self.day = checker, text, day

    def run(self):
        try:
            self.result.emit(self.checker.check(self.text), self.text, self.day)
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, store: Store, dictionary: Dictionary, checker=None):
        super().__init__()
        self.store, self.dictionary = store, dictionary
        self.checker = checker or FrenchChecker()
        self.current_day = QDate.currentDate().toString('yyyy-MM-dd')
        self.saved_text = ''
        self.loading = False
        self.dirty = False
        self.worker = None
        self.pending_close = False
        self.check_text = None
        self.matches = []
        self.setWindowTitle('PepperBean Journal')
        self.setWindowIcon(QIcon(str(ASSETS / 'icon.svg')))
        self.setMinimumSize(980, 650)
        self.resize(1320, 850)
        self.setStyleSheet(STYLE)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(650)
        self.timer.timeout.connect(lambda: self.save_current(automatic=True))
        self.build_ui()
        self.load_day(self.current_day)
        self.refresh_entries()
        save_action = QAction('Lưu', self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(lambda: self.save_current())
        self.addAction(save_action)

    def build_ui(self):
        shell = QWidget()
        layout = QHBoxLayout(shell)
        layout.setContentsMargins(0, 0, 12, 0)
        sidebar = QFrame()
        sidebar.setObjectName('Sidebar')
        sidebar.setFixedWidth(245)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(17, 24, 17, 17)
        side.addWidget(label('PepperBean', 'Brand'))
        side.addWidget(label('J O U R N A L  /  2.0'))
        side.addSpacing(20)
        side.addWidget(button('✎  Viết nhật ký', self.show_today))
        side.addWidget(button('▤  Nhật ký cũ', self.show_history))
        side.addWidget(button('☆  Từ vựng', self.show_vocab))
        side.addSpacing(18)
        side.addWidget(label('NHẬT KÝ CỦA BẠN'))
        self.history_query = QLineEdit()
        self.history_query.setPlaceholderText('Ngày YYYY-MM-DD / nội dung')
        self.history_query.textChanged.connect(self.refresh_entries)
        side.addWidget(self.history_query)
        self.entry_list = QListWidget()
        self.entry_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.entry_list.itemClicked.connect(self.open_entry)
        side.addWidget(self.entry_list, 1)
        side.addWidget(button('Sao lưu dữ liệu', self.backup))
        side.addWidget(button('Phục hồi bản sao lưu', self.restore))
        side.addWidget(button('Hướng dẫn & nguồn dữ liệu', self.about))
        side.addWidget(label('Riêng tư • Hoàn toàn offline'))
        layout.addWidget(sidebar)
        self.pages = QStackedWidget()
        self.pages.addWidget(self.journal_page())
        self.pages.addWidget(self.vocabulary_page())
        layout.addWidget(self.pages, 1)
        self.setCentralWidget(shell)
        self.status = QLabel()
        self.statusBar().addWidget(self.status, 1)

    def journal_page(self):
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(18, 24, 0, 12)
        heading = QHBoxLayout()
        heading.addWidget(label('Un petit moment pour moi.', 'Title'), 1)
        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat('dd/MM/yyyy')
        self.date_edit.dateChanged.connect(self.date_changed)
        heading.addWidget(self.date_edit)
        outer.addLayout(heading)
        outer.addWidget(label('Viết vài dòng bằng tiếng Pháp. Nhấp đúp một từ để xem nghĩa tiếng Anh.'))
        outer.addSpacing(9)
        split = QSplitter(Qt.Orientation.Horizontal)
        center = QWidget()
        central = QVBoxLayout(center)
        central.setContentsMargins(0, 0, 0, 0)
        toolbar = QGridLayout()
        toolbar.addWidget(button('Lưu  ·  Ctrl+S', lambda: self.save_current(), True), 0, 0)
        self.check_button = button('Check French', self.check_french)
        toolbar.addWidget(self.check_button, 0, 1)
        toolbar.addWidget(button('Xuất TXT / MD', self.export_entry), 1, 0)
        toolbar.addWidget(button('Lịch sử sửa', self.revisions), 1, 1)
        central.addLayout(toolbar)
        self.editor = JournalEditor()
        self.editor.setPlaceholderText("Cher journal,\nAujourd’hui, je…")
        self.editor.setTabChangesFocus(True)
        self.editor.textChanged.connect(self.on_changed)
        self.editor.word_lookup.connect(self.lookup_french)
        vertical = QSplitter(Qt.Orientation.Vertical)
        vertical.addWidget(self.editor)
        checks = QWidget()
        check_layout = QVBoxLayout(checks)
        check_layout.setContentsMargins(0, 0, 0, 0)
        self.check_label = label('CHECK FRENCH  ·  Kiểm tra bằng quy tắc, không phải AI')
        check_layout.addWidget(self.check_label)
        self.error_list = QListWidget()
        self.error_list.setMinimumHeight(70)
        self.error_list.currentRowChanged.connect(self.select_error)
        check_layout.addWidget(self.error_list)
        fixes = QHBoxLayout()
        self.suggestions = QComboBox()
        fixes.addWidget(self.suggestions, 1)
        self.apply_button = button('Áp dụng gợi ý', self.apply_correction)
        self.apply_button.setEnabled(False)
        fixes.addWidget(self.apply_button)
        check_layout.addLayout(fixes)
        vertical.addWidget(checks)
        vertical.setSizes([450, 170])
        central.addWidget(vertical, 1)
        split.addWidget(center)
        panel = QWidget()
        panel.setMinimumWidth(270)
        right = QVBoxLayout(panel)
        right.setContentsMargins(8, 0, 0, 0)
        right.addWidget(label('Từ điển offline', 'Title'))
        self.direction = QComboBox()
        self.direction.addItem('English → French', 'en-fr')
        self.direction.addItem('French → English', 'fr-en')
        self.direction.currentIndexChanged.connect(self.clear_lookup)
        right.addWidget(self.direction)
        self.word_query = QLineEdit()
        self.word_query.setPlaceholderText('Nhập một từ hoặc cụm từ…')
        self.word_query.returnPressed.connect(self.lookup)
        right.addWidget(self.word_query)
        right.addWidget(button('Tra từ', self.lookup, True))
        self.lookup_note = label('Nghĩa lấy từ dữ liệu mở; không tự tạo nghĩa hoặc ví dụ.')
        right.addWidget(self.lookup_note)
        self.results = QListWidget()
        self.results.setMaximumHeight(150)
        self.results.currentRowChanged.connect(self.show_definition)
        right.addWidget(self.results)
        self.definition = QTextBrowser()
        self.definition.setOpenExternalLinks(False)
        right.addWidget(self.definition, 1)
        self.insert_button = button('Chèn từ tiếng Pháp', self.insert_word)
        self.vocab_button = button('☆  Lưu từ vựng', self.save_word)
        self.insert_button.setEnabled(False)
        self.vocab_button.setEnabled(False)
        right.addWidget(self.insert_button)
        right.addWidget(self.vocab_button)
        split.addWidget(panel)
        split.setSizes([780, 310])
        outer.addWidget(split, 1)
        return page

    def vocabulary_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(24, 24, 0, 12)
        layout.addWidget(label('Từ vựng của tôi', 'Title'))
        layout.addWidget(label('Những từ bạn đã gặp, lưu cùng nghĩa và ví dụ từ nguồn tra cứu.'))
        self.vocab_query = QLineEdit()
        self.vocab_query.setPlaceholderText('Tìm từ, nghĩa hoặc ví dụ…')
        self.vocab_query.textChanged.connect(self.refresh_vocab)
        layout.addWidget(self.vocab_query)
        split = QSplitter()
        self.vocab_list = QListWidget()
        self.vocab_list.currentItemChanged.connect(self.vocab_selected)
        split.addWidget(self.vocab_list)
        self.vocab_details = QTextBrowser()
        split.addWidget(self.vocab_details)
        layout.addWidget(split, 1)
        layout.addWidget(button('Xóa từ đang chọn', self.delete_vocab))
        return page

    def error(self, text):
        QMessageBox.critical(self, 'PepperBean Journal', text)

    def update_status(self, note=None):
        words = len(re.findall(r"[^\W_]+(?:[’'\-][^\W_]+)*", self.editor.toPlainText(), re.UNICODE))
        state = note or ('Chưa lưu' if self.dirty else 'Đã lưu')
        self.status.setText(f'  {self.current_day}   ·   {words} từ   ·   {state}')

    def on_changed(self):
        if self.loading:
            return
        self.dirty = self.editor.toPlainText() != self.saved_text
        self.clear_errors()
        self.update_status()
        if self.dirty:
            self.timer.start()
        else:
            self.timer.stop()

    def save_current(self, automatic=False):
        self.timer.stop()
        if not self.dirty:
            return True
        text = self.editor.toPlainText()
        if not text.strip() and self.saved_text.strip():
            if automatic:
                self.update_status('Nội dung trống — bấm Lưu để xác nhận')
                return False
            answer = QMessageBox.question(self, 'Xác nhận lưu bài trống',
                'Bạn đã xóa toàn bộ nội dung. Lưu bài trống? Bản trước vẫn còn trong Lịch sử sửa.',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return False
        try:
            self.store.save_entry(self.current_day, text)
        except Exception as exc:
            self.update_status('LƯU THẤT BẠI — nội dung vẫn ở trình soạn thảo')
            if not automatic:
                self.error('Không lưu được. Không đóng ứng dụng; hãy sao chép nội dung ra nơi khác.\n' + str(exc))
            return False
        self.saved_text = text
        self.dirty = False
        self.update_status('Đã lưu lúc ' + datetime.now().strftime('%H:%M:%S'))
        self.refresh_entries()
        return True

    def load_day(self, day):
        # Read first: on failure neither the selected entry nor text is replaced.
        try:
            text = self.store.get_entry(day)
        except Exception as exc:
            self.error('Không đọc được nhật ký.\n' + str(exc))
            return False
        self.timer.stop()
        self.loading = True
        self.current_day = day
        self.saved_text = text
        self.editor.setPlainText(text)
        self.dirty = False
        blocker = QSignalBlocker(self.date_edit)
        self.date_edit.setDate(QDate.fromString(day, 'yyyy-MM-dd'))
        del blocker
        self.loading = False
        self.clear_errors()
        self.update_status()
        return True

    def date_changed(self, date):
        day = date.toString('yyyy-MM-dd')
        if day == self.current_day:
            return
        if self.save_current() and self.load_day(day):
            return
        blocker = QSignalBlocker(self.date_edit)
        self.date_edit.setDate(QDate.fromString(self.current_day, 'yyyy-MM-dd'))
        del blocker

    def refresh_entries(self, *_):
        self.entry_list.clear()
        for entry in self.store.list_entries(self.history_query.text()):
            excerpt = ' '.join(entry['body'].split())[:52] or '(Bài trống)'
            item = QListWidgetItem(entry['day'] + '\n' + excerpt)
            item.setData(Qt.ItemDataRole.UserRole, entry['day'])
            self.entry_list.addItem(item)
            if entry['day'] == self.current_day:
                self.entry_list.setCurrentItem(item)

    def open_entry(self, item):
        # Save may refresh and destroy the clicked QListWidgetItem.
        day = item.data(Qt.ItemDataRole.UserRole)
        if self.save_current() and self.load_day(day):
            self.pages.setCurrentIndex(0)

    def show_today(self):
        if self.save_current() and self.load_day(QDate.currentDate().toString('yyyy-MM-dd')):
            self.pages.setCurrentIndex(0)
            self.editor.setFocus()

    def show_history(self):
        if self.save_current():
            self.pages.setCurrentIndex(0)
            self.history_query.setFocus()

    def lookup_french(self, word):
        self.direction.setCurrentIndex(1)
        self.word_query.setText(word)
        self.lookup()

    def clear_lookup(self, *_):
        self.matches = []
        self.results.clear()
        self.definition.clear()
        self.insert_button.setEnabled(False)
        self.vocab_button.setEnabled(False)

    def lookup(self):
        query = self.word_query.text().strip()
        self.results.clear()
        self.matches = []
        self.definition.clear()
        self.insert_button.setEnabled(False)
        self.vocab_button.setEnabled(False)
        if not query:
            return
        direction = self.direction.currentData()
        try:
            lemmas = self.checker.lemmas(query) if direction == 'fr-en' else ()
            self.matches = self.dictionary.lookup(query, direction, lemmas=lemmas)
        except Exception as exc:
            self.error('Không tra được từ.\n' + str(exc))
            return
        self.lookup_note.setText(f'{len(self.matches)} kết quả cho “{query}”.' if self.matches else
            'Không có mục từ phù hợp trong bộ dữ liệu. Thử từ gốc hoặc cách viết khác.')
        for result in self.matches:
            self.results.addItem(result.get('word', '') + ' → ' + result.get('translation', '')[:85])
        if self.matches:
            self.results.setCurrentRow(0)

    def show_definition(self, row):
        if 0 <= row < len(self.matches):
            record = self.matches[row]
            if not record.get('group'):
                group = self.checker.verb_group(record.get('lemma') or record.get('word', ''))
                record['group'] = group + ' (Grammalecte)' if group else ''
            self.definition.setHtml(definition_html(record))
            self.insert_button.setEnabled(True)
            self.vocab_button.setEnabled(True)
        else:
            self.definition.clear()
            self.insert_button.setEnabled(False)
            self.vocab_button.setEnabled(False)

    def selected_word(self):
        row = self.results.currentRow()
        return self.matches[row] if 0 <= row < len(self.matches) else None

    def insert_word(self):
        record = self.selected_word()
        if record:
            word = record.get('translation') if self.direction.currentData() == 'en-fr' else record.get('word')
            self.editor.insertPlainText(word or '')
            self.editor.setFocus()

    def save_word(self):
        record = self.selected_word()
        if record:
            try:
                self.store.vocab_add(dict(record, direction=self.direction.currentData()))
                self.lookup_note.setText('Đã lưu vào sổ từ vựng.')
            except Exception as exc:
                self.error('Không lưu được từ vựng.\n' + str(exc))

    def show_vocab(self):
        if self.save_current():
            self.refresh_vocab()
            self.pages.setCurrentIndex(1)

    def refresh_vocab(self, *_):
        self.vocab_list.clear()
        self.vocab_details.clear()
        for r in self.store.vocab_list(self.vocab_query.text()):
            item = QListWidgetItem(r.get('word', '') + ' → ' + r.get('translation', ''))
            item.setData(Qt.ItemDataRole.UserRole, r)
            self.vocab_list.addItem(item)
        if self.vocab_list.count():
            self.vocab_list.setCurrentRow(0)

    def vocab_selected(self, item, _previous):
        self.vocab_details.setHtml(definition_html(item.data(Qt.ItemDataRole.UserRole)) if item else '')

    def delete_vocab(self):
        item = self.vocab_list.currentItem()
        if item and QMessageBox.question(self, 'Xóa từ', 'Xóa từ này khỏi sổ từ vựng?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            try:
                self.store.vocab_delete(item.data(Qt.ItemDataRole.UserRole)['id'])
                self.refresh_vocab()
            except Exception as exc:
                self.error(str(exc))

    def clear_errors(self):
        self.check_text = None
        self.error_list.clear()
        self.suggestions.clear()
        self.apply_button.setEnabled(False)
        self.editor.setExtraSelections([])
        self.check_label.setText('CHECK FRENCH  ·  Kiểm tra bằng quy tắc, không phải AI')

    def check_french(self):
        if self.worker and self.worker.isRunning():
            return
        text = self.editor.toPlainText()
        if not text.strip():
            return
        self.clear_errors()
        self.check_button.setEnabled(False)
        self.check_label.setText('Đang kiểm tra offline… Bạn vẫn có thể viết tiếp.')
        self.worker = CheckWorker(self.checker, text, self.current_day, self)
        self.worker.result.connect(self.accept_checks)
        self.worker.failed.connect(self.check_failed)
        self.worker.finished.connect(self.check_finished)
        self.worker.start()

    def check_failed(self, message):
        self.check_label.setText('Kiểm tra thất bại. Nội dung nhật ký không bị thay đổi.')
        self.error('Không chạy được bộ kiểm tra tiếng Pháp.\n' + message)

    def check_finished(self):
        self.check_button.setEnabled(True)
        if self.pending_close:
            QTimer.singleShot(0, self.close)

    def accept_checks(self, errors, text, day):
        if day != self.current_day or text != self.editor.toPlainText():
            self.check_label.setText('Nội dung đã thay đổi. Bấm Check French để kiểm tra lại.')
            return
        self.check_text = text
        self.error_list.clear()
        for e in errors:
            line = text.count('\n', 0, e['start']) + 1
            snippet = text[e['start']:e['end']]
            item = QListWidgetItem(f'Dòng {line} · {snippet} — {e["message"]}')
            item.setData(Qt.ItemDataRole.UserRole, e)
            self.error_list.addItem(item)
        self.check_label.setText(f'{len(errors)} gợi ý · Chọn một lỗi để xem vị trí và cách sửa.' if errors else
            'Không phát hiện lỗi theo bộ quy tắc. Điều này không bảo đảm câu hoàn toàn đúng.')
        if errors:
            self.error_list.setCurrentRow(0)

    def select_error(self, row):
        self.suggestions.clear()
        self.apply_button.setEnabled(False)
        item = self.error_list.item(row)
        if not item or self.check_text != self.editor.toPlainText():
            return
        e = item.data(Qt.ItemDataRole.UserRole)
        cursor = self.editor.textCursor()
        cursor.setPosition(utf16_position(self.check_text, e['start']))
        cursor.setPosition(utf16_position(self.check_text, e['end']), QTextCursor.MoveMode.KeepAnchor)
        self.editor.setTextCursor(cursor)
        self.editor.ensureCursorVisible()
        selection = QTextEdit.ExtraSelection()
        selection.cursor = cursor
        selection.format = QTextCharFormat()
        selection.format.setBackground(QColor('#ffe6aa'))
        self.editor.setExtraSelections([selection])
        self.suggestions.addItems(e['suggestions'])
        self.apply_button.setEnabled(bool(e['suggestions']))

    def apply_correction(self):
        item = self.error_list.currentItem()
        if not item or self.check_text != self.editor.toPlainText() or not self.suggestions.count():
            return
        e = item.data(Qt.ItemDataRole.UserRole)
        replacement = self.suggestions.currentText()
        cursor = self.editor.textCursor()
        cursor.setPosition(utf16_position(self.check_text, e['start']))
        cursor.setPosition(utf16_position(self.check_text, e['end']), QTextCursor.MoveMode.KeepAnchor)
        cursor.insertText(replacement)
        self.editor.setTextCursor(cursor)
        self.check_label.setText('Đã áp dụng một gợi ý. Bấm Check French để kiểm tra lại.')

    def safe_destination(self, path):
        p = Path(path).resolve()
        # Never export over application data, live sidecars or bundled assets.
        forbidden = [self.store.path, Path(str(self.store.path) + '-wal'), Path(str(self.store.path) + '-shm')]
        if p in forbidden or p.is_relative_to(ASSETS.resolve()):
            raise ValueError('Chọn vị trí xuất khác file dữ liệu hoặc tài nguyên ứng dụng.')
        if p.exists() and any(f.exists() and p.samefile(f) for f in forbidden):
            raise ValueError('File này trỏ tới dữ liệu ứng dụng đang sử dụng.')
        return p

    def export_entry(self):
        if not self.save_current():
            return
        path, selected = QFileDialog.getSaveFileName(self, 'Xuất nhật ký', f'{self.current_day}.txt',
            'Văn bản UTF-8 (*.txt);;Markdown (*.md)')
        if path:
            try:
                if not Path(path).suffix:
                    path += '.md' if '*.md' in selected else '.txt'
                p = self.safe_destination(path)
                body = self.editor.toPlainText()
                if p.suffix.lower() == '.md':
                    body = '# ' + self.current_day + '\n\n' + body
                atomic_write(p, body)
                self.update_status('Đã xuất nhật ký')
            except Exception as exc:
                self.error('Xuất nhật ký thất bại.\n' + str(exc))

    def backup(self):
        if not self.save_current():
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Sao lưu nhật ký và từ vựng',
            'PepperBean-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.sqlite3', 'Bản sao lưu (*.sqlite3)')
        if path:
            try:
                self.store.backup(self.safe_destination(path))
                self.update_status('Đã sao lưu nhật ký và từ vựng')
            except Exception as exc:
                self.error('Sao lưu thất bại.\n' + str(exc))

    def restore(self):
        if not self.save_current():
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Chọn bản sao lưu',
            str(self.store.path.parent / 'backups'), 'Bản sao lưu (*.sqlite3)')
        if not path:
            return
        answer = QMessageBox.question(self, 'Phục hồi dữ liệu',
            'Thay nhật ký và từ vựng hiện tại bằng bản sao lưu đã chọn?\n'
            'Ứng dụng sẽ giữ một bản sao dữ liệu hiện tại trước khi phục hồi.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.store.restore(path)
            self.load_day(self.current_day)
            self.refresh_entries()
            self.refresh_vocab()
            self.update_status('Đã phục hồi dữ liệu')
        except Exception as exc:
            self.error('Không phục hồi được.\n' + str(exc))

    def revisions(self):
        if not self.save_current():
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('Lịch sử sửa · ' + self.current_day)
        dialog.resize(720, 500)
        layout = QVBoxLayout(dialog)
        listing = QListWidget()
        preview = QPlainTextEdit()
        preview.setReadOnly(True)
        layout.addWidget(label('Chọn bản cũ để xem. Khôi phục sẽ giữ bản hiện tại trong lịch sử.'))
        layout.addWidget(listing)
        layout.addWidget(preview, 1)
        rows = self.store.list_revisions(self.current_day)
        for row in rows:
            item = QListWidgetItem(row['saved_at'] + ' · ' + row['body'][:70].replace('\n', ' '))
            item.setData(Qt.ItemDataRole.UserRole, row['body'])
            listing.addItem(item)
        listing.currentItemChanged.connect(lambda item, _: preview.setPlainText(item.data(Qt.ItemDataRole.UserRole) if item else ''))
        controls = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        restore_button = controls.addButton('Khôi phục bản đang chọn', QDialogButtonBox.ButtonRole.ActionRole)
        restore_button.setEnabled(bool(rows))
        def apply():
            if listing.currentItem():
                self.editor.setPlainText(listing.currentItem().data(Qt.ItemDataRole.UserRole))
                if self.save_current():
                    dialog.accept()
        restore_button.clicked.connect(apply)
        controls.rejected.connect(dialog.reject)
        layout.addWidget(controls)
        if rows:
            listing.setCurrentRow(0)
        dialog.exec()

    def about(self):
        QMessageBox.information(self, 'PepperBean Journal 2.0',
            'Viết nhật ký → tự lưu sau 0,65 giây ngừng gõ. Ctrl+S để lưu ngay.\n'
            'Chọn ngày bằng lịch hoặc nhấp bài cũ ở thanh bên để sửa.\n'
            'Tra English → French ở bên phải; nhấp đúp từ tiếng Pháp để tra ngược.\n'
            'Check French dùng Grammalecte offline. Bạn tự quyết định áp dụng gợi ý.\n'
            'Sao lưu thường xuyên sang ổ đĩa khác để tránh mất dữ liệu khi hỏng máy.\n\n'
            'Dữ liệu: ' + str(self.store.path.parent) + '\n'
            'Mã nguồn ứng dụng: GPL-3.0-or-later. Xem docs và LICENSES trong gói bàn giao.\n'
            'Không có API, tài khoản, cập nhật tự động hay tải thêm khi mở ứng dụng.')

    def closeEvent(self, event):
        if not self.save_current():
            event.ignore()
            return
        if self.worker and self.worker.isRunning():
            self.pending_close = True
            self.setEnabled(False)
            self.update_status('Đã lưu. Đợi bộ kiểm tra kết thúc để đóng an toàn…')
            event.ignore()
            return
        self.timer.stop()
        event.accept()
