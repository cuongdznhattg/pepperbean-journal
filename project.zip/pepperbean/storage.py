"""Transactional, local-only journal storage. No UI or networking dependencies."""
from __future__ import annotations

from datetime import date, datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import uuid

SCHEMA_VERSION = 1
SQLITE_SIDECARS = ("-wal", "-shm", "-journal")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def _day(value: str) -> str:
    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
        raise ValueError("Ngày phải theo định dạng YYYY-MM-DD.")
    return value


def _sync_directory(path: Path) -> None:
    # Windows does not support opening a directory with os.open for fsync.
    if os.name != "nt":
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _same_file(left: Path, right: Path) -> bool:
    """Detect path aliases and hardlinks without opening SQLite through them."""
    if left == right:
        return True
    try:
        return os.path.samefile(left, right)
    except FileNotFoundError:
        return False


def atomic_write(path: str | Path, text: str) -> None:
    """UTF-8 export: fully write and fsync before replacing the destination."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".pepperbean-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        _sync_directory(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Store:
    """One connection per UI thread; callers must handle surfaced I/O errors.

    A read never creates an empty entry. Editing an existing entry to empty is
    allowed deliberately; its previous text remains in entry_revisions.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=5)
        self.conn.row_factory = sqlite3.Row
        self.last_restore_backup: Path | None = None
        try:
            self.conn.execute("PRAGMA busy_timeout=5000")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.execute("PRAGMA trusted_schema=OFF")
            version = self.conn.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, SCHEMA_VERSION):
                raise ValueError("Dữ liệu thuộc phiên bản khác; không tự hạ cấp.")
            tables = self.conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
            if version == 0 and tables:
                raise ValueError("Đây không phải cơ sở dữ liệu PepperBean Journal 2.0.")
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=FULL")
            if version == 0:
                with self.conn:
                    self.conn.execute("BEGIN IMMEDIATE")
                    self.conn.execute("CREATE TABLE entries (day TEXT PRIMARY KEY, body TEXT NOT NULL, updated TEXT NOT NULL)")
                    self.conn.execute("CREATE TABLE entry_revisions (id INTEGER PRIMARY KEY, day TEXT NOT NULL, body TEXT NOT NULL, saved_at TEXT NOT NULL)")
                    self.conn.execute("CREATE TABLE vocabulary (id INTEGER PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE, payload TEXT NOT NULL, created TEXT NOT NULL)")
                    self.conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
            self._validate(self.conn)
        except Exception:
            self.conn.close()
            raise

    @staticmethod
    def _validate(connection: sqlite3.Connection) -> None:
        if connection.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
            raise ValueError("Bản sao lưu không đúng phiên bản PepperBean Journal 2.0.")
        if connection.execute("PRAGMA quick_check").fetchall()[0][0] != "ok":
            raise ValueError("Bản sao lưu bị hỏng; dữ liệu hiện tại được giữ nguyên.")
        expected = {
            "entries": ["day", "body", "updated"],
            "entry_revisions": ["id", "day", "body", "saved_at"],
            "vocabulary": ["id", "fingerprint", "payload", "created"],
        }
        objects = connection.execute("SELECT type,name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
        if {(r[0], r[1]) for r in objects} != {("table", name) for name in expected}:
            raise ValueError("Cấu trúc cơ sở dữ liệu không hợp lệ.")
        for table, columns in expected.items():
            actual = [row[1] for row in connection.execute(f"PRAGMA table_info({table})")]
            if actual != columns:
                raise ValueError("Cấu trúc bản sao lưu không hợp lệ.")

    def get_entry(self, day: str) -> str:
        row = self.conn.execute("SELECT body FROM entries WHERE day=?", (_day(day),)).fetchone()
        return row[0] if row else ""

    def save_entry(self, day: str, body: str) -> None:
        day = _day(day)
        if not isinstance(body, str):
            raise TypeError("Nội dung phải là văn bản.")
        with self.conn:
            # Acquire write reservation before read/modify/write.
            self.conn.execute("BEGIN IMMEDIATE")
            old = self.conn.execute("SELECT body FROM entries WHERE day=?", (day,)).fetchone()
            if (old and old[0] == body) or (old is None and body == ""):
                return
            now = _now()
            if old:
                self.conn.execute("INSERT INTO entry_revisions(day,body,saved_at) VALUES(?,?,?)", (day, old[0], now))
            self.conn.execute("INSERT INTO entries(day,body,updated) VALUES(?,?,?) ON CONFLICT(day) DO UPDATE SET body=excluded.body,updated=excluded.updated", (day, body, now))

    def list_entries(self, query: str = "") -> list[dict]:
        query = query.casefold().strip()
        rows = self.conn.execute("SELECT day,body,updated FROM entries ORDER BY day DESC").fetchall()
        return [dict(r) for r in rows if not query or query in r["day"] or query in r["body"].casefold()]

    def list_revisions(self, day: str) -> list[dict]:
        """Previous texts for one date, newest first; current text is excluded."""
        return [dict(row) for row in self.conn.execute(
            "SELECT id,body,saved_at FROM entry_revisions WHERE day=? ORDER BY id DESC",
            (_day(day),),
        )]

    def vocab_add(self, record: dict) -> int:
        if not isinstance(record, dict):
            raise TypeError("Từ vựng phải là một bản ghi.")
        clean = {k: v for k, v in record.items() if k != "id"}
        payload = json.dumps(clean, ensure_ascii=False, sort_keys=True, allow_nan=False)
        fingerprint = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        with self.conn:
            self.conn.execute("INSERT OR IGNORE INTO vocabulary(fingerprint,payload,created) VALUES(?,?,?)", (fingerprint, payload, _now()))
        return self.conn.execute("SELECT id FROM vocabulary WHERE fingerprint=?", (fingerprint,)).fetchone()[0]

    def vocab_list(self, query: str = "") -> list[dict]:
        query = query.casefold().strip()
        result = []
        for row in self.conn.execute("SELECT id,payload FROM vocabulary ORDER BY id DESC"):
            if not query or query in row["payload"].casefold():
                result.append({**json.loads(row["payload"]), "id": row["id"]})
        return result

    def vocab_delete(self, identifier: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM vocabulary WHERE id=?", (identifier,))

    def _check_snapshot_path(self, path: Path) -> None:
        protected = [self.path, *(Path(str(self.path) + suffix) for suffix in SQLITE_SIDECARS)]
        if any(_same_file(path, other) for other in protected):
            raise ValueError("Chọn một file khác file dữ liệu đang sử dụng và các file phụ của nó.")
        if path.name.endswith(SQLITE_SIDECARS):
            raise ValueError("Không thể dùng file phụ SQLite làm bản sao lưu.")
        if any(Path(str(path) + suffix).exists() for suffix in SQLITE_SIDECARS):
            raise ValueError("File này có file phụ SQLite; hãy đóng ứng dụng đang dùng file hoặc chọn bản sao lưu độc lập.")

    def backup(self, path: str | Path) -> Path:
        """Snapshot committed WAL content, validate, then atomically publish."""
        target = Path(path).resolve()
        self._check_snapshot_path(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".pepperbean-backup-", dir=target.parent)
        os.close(fd)
        try:
            snapshot = sqlite3.connect(name)
            try:
                self.conn.backup(snapshot)
                # Standalone snapshots must not depend on a WAL sidecar.
                snapshot.execute("PRAGMA journal_mode=DELETE")
                self._validate(snapshot)
            finally:
                snapshot.close()
            # FlushFileBuffers on Windows requires a writable handle.
            with open(name, "r+b") as stream:
                os.fsync(stream.fileno())
            self._check_snapshot_path(target)
            os.replace(name, target)
            _sync_directory(target.parent)
        finally:
            if os.path.exists(name):
                os.unlink(name)
        return target

    def restore(self, path: str | Path) -> None:
        """Validate a read-only snapshot, back up current state, import atomically.

        Only data is imported, never SQL definitions from the supplied file.
        Any error rolls the restore transaction back; the pre-restore backup is
        retained independently and is exposed via last_restore_backup.
        """
        source_path = Path(path).resolve()
        self._check_snapshot_path(source_path)
        source = sqlite3.connect(source_path.as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            source.execute("PRAGMA trusted_schema=OFF")
            source.execute("PRAGMA query_only=ON")
            source.execute("BEGIN")
            self._validate(source)
            entries = source.execute("SELECT day,body,updated FROM entries").fetchall()
            revisions = source.execute("SELECT id,day,body,saved_at FROM entry_revisions").fetchall()
            vocabulary = source.execute("SELECT id,fingerprint,payload,created FROM vocabulary").fetchall()
            for day, body, updated in entries:
                _day(day)
                if not isinstance(body, str) or not isinstance(updated, str):
                    raise ValueError("Bản ghi nhật ký không hợp lệ.")
            for identifier, day, body, saved_at in revisions:
                _day(day)
                if not isinstance(identifier, int) or not isinstance(body, str) or not isinstance(saved_at, str):
                    raise ValueError("Lịch sử chỉnh sửa không hợp lệ.")
            for identifier, fingerprint, payload, created in vocabulary:
                if not isinstance(identifier, int) or not isinstance(created, str) or not isinstance(json.loads(payload), dict):
                    raise ValueError("Bản ghi từ vựng không hợp lệ.")
                if hashlib.sha256(payload.encode("utf-8")).hexdigest() != fingerprint:
                    raise ValueError("Bản ghi từ vựng bị thay đổi hoặc hỏng.")
        finally:
            source.close()
        name = "before-restore-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8] + ".sqlite3"
        self.last_restore_backup = self.backup(self.path.parent / "backups" / name)
        with self.conn:
            self.conn.execute("BEGIN IMMEDIATE")
            self.conn.execute("DELETE FROM entries")
            self.conn.execute("DELETE FROM entry_revisions")
            self.conn.execute("DELETE FROM vocabulary")
            self.conn.executemany("INSERT INTO entries(day,body,updated) VALUES(?,?,?)", entries)
            self.conn.executemany("INSERT INTO entry_revisions(id,day,body,saved_at) VALUES(?,?,?,?)", revisions)
            self.conn.executemany("INSERT INTO vocabulary(id,fingerprint,payload,created) VALUES(?,?,?,?)", vocabulary)

    def close(self) -> None:
        self.conn.close()
