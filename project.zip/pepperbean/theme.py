STYLE = '''
QWidget { font-family: "Segoe UI", "DejaVu Sans"; font-size: 13px; color: #244337; }
QMainWindow, QDialog { background: #f7f8f3; }
QFrame#Sidebar { background: #edf3ed; border-right: 1px solid #d9e4da; }
QLabel#Brand { font-size: 22px; font-weight: 700; }
QLabel#Title { font-size: 24px; font-weight: 600; }
QLabel#Muted { color: #65766b; }
QPushButton { background: #ffffff; border: 1px solid #cfddd2; border-radius: 7px; padding: 9px 13px; }
QPushButton:hover { background: #e6f1e9; border-color: #95b49e; }
QPushButton:pressed, QPushButton:checked { background: #cfe5d7; }
QPushButton#Primary { background: #376a52; color: white; border-color: #376a52; font-weight: 600; }
QPushButton#Primary:hover { background: #28543f; }
QPushButton:disabled { color: #9aa79e; background: #eff2ed; }
QPlainTextEdit, QTextBrowser, QLineEdit, QDateEdit, QComboBox, QListWidget { background: #fffefa; border: 1px solid #d4dfd4; border-radius: 7px; padding: 8px; selection-background-color: #c6e2d2; selection-color: #173529; }
QPlainTextEdit { font-size: 17px; padding: 20px; }
QListWidget::item { padding: 9px; border-bottom: 1px solid #edf0e9; }
QListWidget::item:selected { background: #dceee1; color: #204631; }
QTabWidget::pane { border: 0px; }
QTabBar::tab { padding: 9px 14px; background: #edf3ed; }
QTabBar::tab:selected { background: #d8e9dd; }
QStatusBar { background: #edf3ed; padding: 4px; }
QSplitter::handle { background: #f7f8f3; width: 8px; height: 8px; }
QToolTip { background: #ffffff; border: 1px solid #cfddd2; padding: 5px; }
'''
