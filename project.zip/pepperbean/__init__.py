"""PepperBean Journal 2.0 — local-first French journal."""
__version__ = "2.0.0rc1"
