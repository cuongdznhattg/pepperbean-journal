"""Local Grammalecte integration. Error offsets use Python Unicode code points.

No network, subprocess, Java or per-user dictionary installation is used.
All Grammalecte entry points share a lock because its engine has global caches.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys
import threading

_LOCK = threading.RLock()
_ENGINE = None


def _engine():
    global _ENGINE
    with _LOCK:
        if _ENGINE is None:
            root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
            vendor = root / "vendor"
            if vendor.is_dir() and str(vendor) not in sys.path:
                sys.path.insert(0, str(vendor))
            from grammalecte.grammar_checker import GrammarChecker
            _ENGINE = GrammarChecker("fr")
        return _ENGINE


class FrenchChecker:
    """Rule-based French spelling/grammar checker; exceptions propagate to UI."""

    def __init__(self):
        self.engine = _engine()

    def check(self, text: str) -> list[dict]:
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        results = []
        with _LOCK:
            # Slice each paragraph directly from the ORIGINAL text: never strip,
            # normalize apostrophes, or replace CRLF, which would shift offsets.
            for paragraph in re.finditer(r"[^\r\n]+", text):
                value = paragraph.group()
                grammar, spelling = self.engine.getParagraphErrors(
                    value, bSpellSugg=True
                )
                for kind, errors in (("grammar", grammar), ("spelling", spelling)):
                    for error in errors:
                        start, end = error["nStart"], error["nEnd"]
                        if not 0 <= start <= end <= len(value):
                            raise RuntimeError("Grammalecte returned invalid offsets")
                        results.append({
                            "start": paragraph.start() + start,
                            "end": paragraph.start() + end,
                            "message": error.get("sMessage") or (
                                "Mot absent du dictionnaire : " + error.get("sValue", "")
                            ),
                            "suggestions": list(dict.fromkeys(error.get("aSuggestions", []))),
                            "kind": kind,
                            "rule": error.get("sRuleId", "SPELLING"),
                        })
        return sorted(results, key=lambda item: (item["start"], item["end"], item["kind"]))

    def lemmas(self, word: str) -> list[str]:
        with _LOCK:
            # Return all candidates: "suis" can be être OR suivre.
            return sorted(self.engine.getSpellChecker().getLemma(word.strip()))

    def verb_group(self, word: str) -> str:
        """Return source classification only when unambiguous and appropriate.

        Grammalecte internally puts aller in group 1; suppress this technical
        classification instead of presenting it as a school grammar group.
        """
        with _LOCK:
            from grammalecte.fr import conj
            candidates = self.lemmas(word)
            verbs = [lemma for lemma in candidates if conj.isVerb(lemma)]
            if len(verbs) != 1 or verbs[0] == "aller":
                return ""
            code = conj.getVtyp(verbs[0])
            return {"1": "1", "2": "2", "3": "3"}.get(code[0] if code else "", "")


def utf16_position(text: str, codepoint_position: int) -> int:
    """Convert a checker offset to Qt QTextCursor's UTF-16 position."""
    if not 0 <= codepoint_position <= len(text):
        raise ValueError("Offset outside text")
    return len(text[:codepoint_position].encode("utf-16-le")) // 2
