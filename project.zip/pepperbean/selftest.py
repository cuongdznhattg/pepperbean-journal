"""Packaged-app smoke test. Does not touch the user's LocalAppData."""
from datetime import date
import json
import platform
from pathlib import Path
import socket
import tempfile
import time
import traceback


def run(app, report=None):
    from .paths import ASSETS
    from .storage import Store, atomic_write
    from .dictionary import Dictionary
    from .grammar import FrenchChecker
    from .ui import MainWindow
    result = {'platform': platform.platform(), 'python': platform.python_version(),
              'network': 'socket connect/create_connection blocked during test',
              'clean_windows_11_tested': False, 'checks': [], 'passed': False}
    original_connect = socket.socket.connect
    original_create = socket.create_connection
    original_connect_ex = socket.socket.connect_ex
    def deny(*args, **kwargs):
        raise AssertionError('Network access attempted during offline smoke test')
    socket.socket.connect = deny
    socket.socket.connect_ex = deny
    socket.create_connection = deny
    store = dictionary = window = None
    started = time.monotonic()
    try:
        with tempfile.TemporaryDirectory(prefix='pepperbean-selftest-') as directory:
            root = Path(directory)
            store = Store(root / 'journal.sqlite3')
            dictionary = Dictionary(ASSETS / 'dictionary.sqlite3')
            checker = FrenchChecker()
            window = MainWindow(store, dictionary, checker)
            window.show()
            app.processEvents()
            assert window.editor.toPlainText() == ''
            result['checks'].append('first GUI launch empty without creating entry')
            text = '😀 Aujourd’hui, je suis heureux.\nJe mange une pomme.'
            window.editor.setPlainText(text)
            assert window.save_current()
            day = window.current_day
            window.close()
            app.processEvents()
            store.close()
            store = Store(root / 'journal.sqlite3')
            window = MainWindow(store, dictionary, checker)
            assert window.editor.toPlainText() == text
            result['checks'].append('GUI save, close, reopen, exact accented text')
            old = '2020-02-29'
            window.load_day(old)
            window.editor.setPlainText('Mon ancien journal.')
            assert window.save_current()
            window.load_day(day)
            window.load_day(old)
            window.editor.appendPlainText('Une autre phrase.')
            assert window.save_current()
            assert len(store.list_revisions(old)) == 1
            result['checks'].append('open and edit older diary with revision')
            en = dictionary.lookup('apple', 'en-fr')
            assert en and any('pomme' in r['translation'] for r in en)
            window.lookup_french('suis')
            assert window.results.count() > 0
            result['checks'].append('real EN→FR and inflected FR→EN dictionary')
            window.save_word()
            assert store.vocab_list()
            result['checks'].append('save vocabulary')
            errors = checker.check('Les chats mange une pommme.')
            assert any(e['kind'] == 'grammar' for e in errors)
            assert any(e['kind'] == 'spelling' for e in errors)
            result['checks'].append('real French grammar and spelling suggestions')
            backup = root / 'backup.sqlite3'
            store.backup(backup)
            store.save_entry(old, 'Changed')
            store.restore(backup)
            assert store.get_entry(old) == 'Mon ancien journal.\nUne autre phrase.'
            assert store.vocab_list()
            result['checks'].append('backup and restore diary plus vocabulary')
            atomic_write(root / 'export.txt', text)
            assert (root / 'export.txt').read_text(encoding='utf8') == text
            result['checks'].append('UTF-8 atomic export')
            window.close()
            app.processEvents()
            window = None
            store.close()
            store = None
            dictionary.close()
            dictionary = None
        result['passed'] = True
    except Exception:
        result['error'] = traceback.format_exc()
    finally:
        if window:
            window.timer.stop()
            window.dirty = False
            window.close()
        if dictionary:
            dictionary.close()
        if store:
            store.close()
        socket.socket.connect = original_connect
        socket.socket.connect_ex = original_connect_ex
        socket.create_connection = original_create
    result['elapsed_seconds'] = round(time.monotonic() - started, 3)
    output = json.dumps(result, ensure_ascii=False, indent=2)
    if report:
        atomic_write(report, output)
    if __import__('sys').stdout:
        print(output)
    return 0 if result['passed'] else 1
