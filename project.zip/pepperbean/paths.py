from pathlib import Path
import os
import sys

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
ASSETS = ROOT / 'assets'

def data_directory():
    if sys.platform == 'win32':
        base = os.environ.get('LOCALAPPDATA')
        if not base:
            raise RuntimeError('Không tìm thấy LocalAppData; không mở cơ sở dữ liệu ở thư mục khác.')
        return Path(base) / 'PepperBeanJournal'
    # Development/test hosts only. Windows always uses LocalAppData.
    return Path(os.environ.get('XDG_DATA_HOME', Path.home() / '.local' / 'share')) / 'PepperBeanJournal'
