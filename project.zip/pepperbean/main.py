"""Desktop entry point. Never downloads resources or runs an updater."""
import argparse
from datetime import date
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.self_test:
        os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtCore import QLockFile
    from PySide6.QtWidgets import QApplication, QMessageBox
    from .paths import data_directory, ASSETS
    from .storage import Store
    from .dictionary import Dictionary
    from .ui import MainWindow
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName('PepperBeanJournal')
    app.setOrganizationName('PepperBean')
    if args.self_test:
        from .selftest import run
        return run(app, args.report)
    store = dictionary = lock = None
    try:
        data = data_directory()
        data.mkdir(parents=True, exist_ok=True)
        lock = QLockFile(str(data / 'journal.lock'))
        # Disable time-only stale detection; Qt still detects dead processes.
        lock.setStaleLockTime(0)
        if not lock.tryLock(100):
            QMessageBox.information(None, 'PepperBean Journal',
                'Ứng dụng đã mở hoặc không khóa được thư mục dữ liệu. Hãy kiểm tra cửa sổ đang chạy.')
            return 1
        database = data / 'journal.sqlite3'
        existed = database.exists()
        store = Store(database)
        if existed:
            daily = data / 'backups' / ('auto-' + date.today().isoformat() + '.sqlite3')
            if not daily.exists():
                # Fail safely if backup cannot be created; do not silently continue.
                store.backup(daily)
        dictionary = Dictionary(ASSETS / 'dictionary.sqlite3')
        window = MainWindow(store, dictionary)
        # Unhandled UI errors must be visible, without recording private diary text.
        def report_error(exc_type, exc, tb):
            QMessageBox.critical(window, 'PepperBean Journal',
                'Thao tác gặp lỗi. Nội dung chưa lưu vẫn ở trình soạn thảo.\n' + str(exc))
        sys.excepthook = report_error
        window.show()
        return app.exec()
    except Exception as exc:
        QMessageBox.critical(None, 'Không mở được PepperBean Journal',
            'Ứng dụng chưa thể khởi động. Không tự xóa hoặc tạo lại dữ liệu cũ.\n'
            'Giữ nguyên thư mục dữ liệu và bản sao lưu để xử lý lỗi.\n\n' + str(exc))
        return 1
    finally:
        if dictionary is not None and hasattr(dictionary, 'close'):
            dictionary.close()
        if store is not None:
            store.close()
        if lock is not None:
            lock.unlock()
