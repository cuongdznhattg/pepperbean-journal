"""Fully offline read-only dictionary with sourced inflection lookup."""
from __future__ import annotations
from pathlib import Path
import sqlite3
import unicodedata


def normalize(text: str) -> str:
    return unicodedata.normalize('NFC',text).replace('’',"'").strip().casefold()


class Dictionary:
    def __init__(self,path):
        path=Path(path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f'Missing offline dictionary: {path}')
        self.db=sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1',uri=True)
        self.db.row_factory=sqlite3.Row
        version=self.db.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
        if not version or version[0]!='1':
            self.db.close()
            raise ValueError('Unsupported dictionary database version')

    def close(self):
        self.db.close()

    def stats(self):
        return {r['key']:r['value'] for r in self.db.execute('SELECT * FROM metadata')}

    def lookup(self,query: str,direction: str='en-fr',lemmas=(),limit: int=60):
        """Return exact/lemma matches, never generate translations.

        word = source-language headword; translation = destination-language text.
        lemma is always the French canonical word. Unknown metadata = empty string.
        English search includes direct FreeDict entries and explicitly labelled
        reverse English-gloss matches from French Wiktionary. Definition retains
        the complete gloss, so a reverse search doesn't erase sense context.
        """
        if direction not in ('en-fr','fr-en'):
            raise ValueError('direction must be en-fr or fr-en')
        query=normalize(query)
        limit=max(1,min(int(limit),200))
        if not query or len(query)>200:return []
        if direction=='en-fr' and query.startswith('to '):
            keys=[query,query[3:]]
        else:keys=[query]
        if direction=='fr-en':
            # Breadth-first form graph permits linked variants, bounded against cycles.
            seen=set(keys)
            for _ in range(3):
                added=[]
                for current in list(keys):
                    for row in self.db.execute('SELECT lemma FROM forms WHERE form=? ORDER BY lemma LIMIT 20',(current,)):
                        if row[0] not in seen:
                            seen.add(row[0]);added.append(row[0])
                keys.extend(added)
                if not added:break
            keys.extend(normalize(v) for v in lemmas if isinstance(v,str))
        results=[];dedupe=set()
        for term in dict.fromkeys(keys):
            rows=self.db.execute('SELECT * FROM entries WHERE direction=? AND lookup_key=? ORDER BY priority,id LIMIT ?', (direction,term,limit))
            for row in rows:
                item=dict(row)
                unique=(item['word'],item['translation'],item['pos'],item['definition'])
                if unique in dedupe:continue
                dedupe.add(unique)
                record={k:item[k] for k in ('word','translation','pos','gender','example','example_translation','source','lemma','definition','match_kind')}
                record['group']=item['verb_group']
                if term != query and direction=='fr-en':record['match_kind']='inflected-form'
                results.append(record)
                if len(results)>=limit:return results
        return results
