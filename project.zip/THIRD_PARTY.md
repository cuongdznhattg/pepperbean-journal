# Sources and licenses

The newly written PepperBean application code is Copyright (c) 2026 PepperBean Journal contributors, licensed GPL-3.0-or-later (full text in LICENSE). Existing components retain their own copyright and license notices. No PepperBean Journal 1.0 code was used.

| Component | Version / source | License and included material |
|---|---|---|
| FreeDict English–French | 0.1.6, 8,799 headwords | GPL-2.0-or-later. Complete TEI including authors/history in assets/dictionary_sources/eng-fra.tei; license in same folder and LICENSES. |
| FreeDict French–English | 0.4.1, 8,505 headwords | GPL-2.0-or-later. Complete TEI including authors/history in assets/dictionary_sources/fra-eng.tei. |
| Wiktionary contributors via Kaikki/wiktextract | French data extracted 2026-10-30 from enwiktionary 2026-10-01 | CC BY-SA 4.0. Compact transformed dataset, source URLs, SHA256 and license in assets/dictionary_sources. Every derived dictionary result carries attribution and original Wiktionary headword URL. |
| Grammalecte, Olivier R. and contributors; derived from Lightproof by László Németh | 2.3.0, https://grammalecte.net/ | GPL-3.0. Original Python sources, dictionaries and English/French license notices included in vendor, unmodified. Original archive URL/hash in docs/grammalecte-source.json. |
| PySide6 / Shiboken6, The Qt Company and contributors | 6.8.3, https://code.qt.io/pyside/pyside-setup.git/tag/?h=v6.8.3 | LGPL-3.0 / GPL options; original upstream copyright notices apply. Used unmodified and dynamically linked in the portable build. License texts included in LICENSES. Matching source: https://download.qt.io/official_releases/QtForPython/pyside6/PySide6-6.8.3-src/ |
| Qt, The Qt Company and contributors | 6.8.3, https://code.qt.io/qt/qtbase.git/tag/?h=v6.8.3 | Open source GPL/LGPL options and third-party notices. Dynamic libraries remain replaceable in _internal; no technical restriction on modification/relinking. Matching source: https://download.qt.io/archive/qt/6.8/6.8.3/single/ |
| CPython, Python Software Foundation and contributors | Build uses Python 3.12 | PSF License and included notices. Source: https://www.python.org/downloads/source/ . Build script copies the exact build interpreter LICENSE.txt into the portable package. |
| PyInstaller contributors | 6.16.0 | GPL with bootloader distribution exception; full COPYING.txt in LICENSES. https://github.com/pyinstaller/pyinstaller/tree/v6.16.0 |

The SQLite dictionary is a compilation of distinguishable attributed source records. FreeDict-derived rows retain GPL terms; Wiktionary-derived/modified records and the compact dataset retain CC BY-SA 4.0 attribution/share-alike terms. The offline converter is included. Changes: field reduction, Unicode normalization, gloss-based reverse lookup, source metadata enrichment, and inflection indexing; see docs/DICTIONARY.md. These are not independently authored definitions.

English reverse-gloss search is explicitly labelled in the UI; it must not be advertised as the original English Wiktionary dataset. External quotations with reference metadata were excluded from example extraction; included examples are sourced dictionary usage examples.

Data license pointers: https://freedict.org/ and https://kaikki.org/dictionary/French/ and https://en.wiktionary.org/wiki/Wiktionary:Copyrights . Full TEI headers preserve FreeDict original credits and revision history. Data provenance and checksums are in assets/dictionary_sources/manifest.json.

The Windows build attaches application/vendor/data corresponding source in Source.zip. Build/test tooling is installed only on the build host, not required from end users. No paid API or proprietary dictionary is bundled. GitHub Actions is optional build infrastructure subject to the account's own service quota.
