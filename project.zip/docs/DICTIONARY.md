# Bộ từ điển offline — PepperBean Journal 2.0

## Dữ liệu thực tế đã đóng gói

Đây là dữ liệu từ điển mở thật, không phải danh sách mẫu hoặc nghĩa do mô hình sinh.

| Thành phần | Số lượng |
|---|---:|
| FreeDict English–French, bản 0.1.6 | 8.799 mục từ gốc |
| FreeDict French–English, bản 0.4.1 | 8.505 mục từ gốc |
| Kaikki/Wiktionary French, số bản ghi đầu vào | 404.127 |
| Nghĩa từ vựng Kaikki được giữ lại | 122.493 |
| Khóa tra tiếng Anh, sau kết hợp các nguồn | 87.665 |
| Khóa tra từ vựng tiếng Pháp, sau kết hợp | 92.456 |
| Dạng biến đổi tiếng Pháp phân biệt có ánh xạ | 371.058 |
| Cặp dạng biến đổi → từ gốc | 377.074 |

**87.665 khóa tiếng Anh không đồng nghĩa với 87.665 mục từ Anh–Pháp biên soạn độc lập.** Chúng gồm mục từ FreeDict, đảo các bản dịch thật từ FreeDict Pháp–Anh và chỉ mục đảo các tương đương tiếng Anh ngắn trong định nghĩa Wiktionary tiếng Pháp. Chế độ tra hiển thị nguồn, kiểu khớp và định nghĩa đầy đủ để người dùng phân biệt nghĩa. Không dùng tìm kiếm từ xuất hiện tùy tiện trong định nghĩa dài để tạo ra bản dịch.

DB SQLite dựng sẵn khoảng 95,6 MiB; dữ liệu nguồn nén và TEI khoảng 21 MiB. Có thể dựng lại DB hoàn toàn offline từ nguồn đã đóng gói, bằng `python tools/build_dictionary.py`. Lệnh này dành cho người phát triển/quy trình build, không dành cho người sử dụng bản `.exe`.

## Cách tra

- Anh → Pháp: ưu tiên mục FreeDict gốc; sau đó bổ sung tương đương từ các nguồn còn lại. Ví dụ `computer` → `ordinateur`, `eat` → `manger`.
- Pháp → Anh: khớp mục từ trước, rồi tra ánh xạ dạng biến đổi từ Wiktionary; ví dụ `mangeais` → `manger`, `allons` → `aller`.
- Một dạng có nhiều từ gốc vẫn giữ nhiều kết quả: `suis` có thể từ `être` hoặc `suivre`. Không tự chọn một nghĩa dựa trên câu.
- Chuẩn hóa Unicode NFC, chữ hoa/thường và dấu nháy cong. Không bỏ dấu tiếng Pháp vì việc đó có thể trộn các từ khác nhau (`a`/`à`).
- Từ loại và giống trong kết quả Anh → Pháp nói về **từ tiếng Pháp đích**, chỉ lấy từ bản ghi Pháp đã đối chiếu hoặc nguồn Pháp–Anh, không suy từ từ loại tiếng Anh.
- DB từ điển không tự suy nhóm động từ. Giao diện bổ sung nhóm từ dữ liệu Grammalecte khi có phân loại rõ ràng và ghi nguồn bên cạnh; để trống khi không rõ hoặc với phân loại kỹ thuật không phù hợp như `aller`. Không suy nhóm chỉ từ hậu tố `-er`/`-ir`.
- Ví dụ/diễn giải tiếng Anh chỉ xuất hiện khi nguồn có. Không tự viết thêm. Chỉ giữ ví dụ có `type=example` và không có trường tham chiếu ngoài; loại các trích dẫn sách/báo (`type=quote`).
- `definition` giữ toàn bộ nghĩa tiếng Anh của mục phù hợp và nhãn cách dùng khi nguồn có. Một từ có nhiều nghĩa được hiển thị nhiều kết quả, ví dụ `work` có thể là động từ hoặc danh từ.

## Độ bao phủ đã kiểm tra

Danh sách **104 từ tiếng Anh thường dùng** trong bộ kiểm tra; cả 104 đều có ít nhất một kết quả. Danh sách đầy đủ và ba kết quả đầu của từng từ nằm ở `assets/dictionary_sources/daily-vocabulary-check.json`. Đây là **tỷ lệ có kết quả trên mẫu nhỏ**, không phải đánh giá độ chính xác dịch, không chứng minh bao phủ 100% ngôn ngữ. Mẫu kiểm tra thiên về giao tiếp thường ngày, không phải mẫu ngẫu nhiên độc lập.

23 kiểm thử tự động trong `tests/test_dictionary.py` kiểm tra các cặp nghĩa cụ thể, từ chia, giống danh từ, ví dụ có nguồn, Unicode, không sinh nghĩa cho từ không tồn tại, chống SQL injection qua query, DB chỉ đọc, phạm vi dữ liệu và tính toàn vẹn SQLite. Các kết quả này được chạy trên Linux, không phải kiểm thử Windows.

## Giới hạn

- Không dịch cả câu; không chọn nghĩa theo ngữ cảnh như mô hình ngôn ngữ.
- Không phải từ điển tiếng Việt. Nghĩa/giải thích nguồn bằng tiếng Anh.
- FreeDict tương đối cũ, Wiktionary do cộng đồng biên soạn; dữ liệu có thể sai, thiếu, mang nghĩa vùng miền/cổ/tiếng lóng. Giữ các nhãn có trong nguồn, nhưng nguồn không gắn nhãn nhất quán cho mọi nghĩa.
- Trường từ loại, giống, ví dụ còn thiếu ở một số mục. Để trống thay vì đoán.
- Nhiều từ chuyên ngành/cụm dài không được chỉ mục đảo tiếng Anh; không có kết quả không có nghĩa từ đó không tồn tại.
- Tối đa 60 kết quả mỗi lượt theo mặc định; thư viện cho phép tăng đến 200. Mục nhiều nghĩa có thể bị cắt ở giới hạn này.
- Ánh xạ dạng biến đổi là tra từ dữ liệu, không phân tích đầy đủ cấu trúc câu hoặc ngữ cảnh.

## Nguồn, giấy phép và ghi nhận tác giả

### FreeDict

- [English–French source](https://github.com/freedict/fd-dictionaries/blob/master/eng-fra/eng-fra.tei)
- [French–English source](https://github.com/freedict/fd-dictionaries/blob/master/fra-eng/fra-eng.tei)
- [FreeDict project](https://freedict.org/)
- **GPL-2.0-or-later**. Giữ nguyên các tệp TEI cùng toàn bộ `teiHeader`, tên tác giả, lịch sử và thông tin giấy phép. Văn bản GPL được đóng gói ở `assets/dictionary_sources/GPL-2.0.txt`.
- Tác giả/bên biên soạn được nguồn ghi nhận gồm Horst Eyermann, John Darrington, Michael Bunk, Piotr Bański, Sebastian Humenda, Sylvain Leroux và các cộng tác viên FreeDict/Ergane; xem header nguồn để biết đầy đủ và vai trò từng người.
- Các bản ghi FreeDict và phần dữ liệu chuyển đổi tương ứng giữ GPL-2.0-or-later. Việc đặt chung trong một DB không đổi giấy phép của các bản ghi Kaikki/Wiktionary độc lập.

### Kaikki / Wiktionary

- [French dictionary snapshot source](https://kaikki.org/dictionary/French/index.html)
- [Original JSONL download](https://kaikki.org/dictionary/French/kaikki.org-dictionary-French.jsonl)
- Dữ liệu trang nguồn ghi: enwiktionary dump **2026-10-01**, trích xuất **2026-10-30**. Tải ngày **2026-11-06 UTC**.
- Tác giả nội dung: **Wiktionary contributors**. Mỗi kết quả chứa đường dẫn về mục từ tiếng Pháp trên en.wiktionary.org; lịch sử tác giả tại tab View history của mục tương ứng.
- Trích xuất: **Tatu Ylonen / Kaikki.org / Wiktextract**. Công trình: *Wiktextract: Wiktionary as Machine-Readable Structured Data*, LREC 2022, pp. 1317–1325.
- Chọn giấy phép **Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)** cho nội dung Wiktionary và dữ liệu dẫn xuất tương ứng. [Thông tin bản quyền Wiktionary](https://en.wiktionary.org/wiki/Wiktionary:Copyrights); [toàn văn giấy phép](https://creativecommons.org/licenses/by-sa/4.0/legalcode.en). Bản toàn văn được đóng gói ở `assets/dictionary_sources/CC-BY-SA-4.0.txt`.
- Thay đổi của dự án: bỏ âm thanh, hình ảnh, từ nguyên, các ngôn ngữ khác và dữ liệu không dùng; giữ nghĩa, từ loại, nhãn, ví dụ không phải trích dẫn và dạng biến đổi; chuẩn hóa khóa tra; chuyển sang SQLite; lập chỉ mục đảo các tương đương ngắn; loại nghĩa chỉ mô tả “dạng chia của...” khỏi bảng nghĩa và chuyển chúng thành ánh xạ. Không sửa nội dung nghĩa/ví dụ nguồn.
- `kaikki-fr-compact.jsonl.gz` là bản nguồn rút gọn theo trường, vẫn CC BY-SA 4.0, dùng để dựng DB offline. Hàm `compact_kaikki` và tùy chọn `--compact-from ... --compact-output ...` trong script thể hiện phép biến đổi từ JSONL gốc. Không cần tải lại JSONL gốc để build bản này.
- Văn bản giấy phép được tải từ kho SPDX license-list-data (bản sao toàn văn giấy phép), URL nằm trong manifest.

`assets/dictionary_sources/manifest.json` lưu SHA-256 của toàn bộ nguồn đóng gói, URL, giấy phép, ngày snapshot và SHA-256 của JSONL gốc 592.920.809 byte. Script build từ chối chạy nếu checksum nguồn khác; không tự tải snapshot mới. Các URL `master` có thể thay đổi sau này, nên bản nguồn đã đóng gói cùng checksum mới là đầu vào chính xác để tái dựng phiên bản này.

## Giao diện lập trình

```python
from pepperbean.dictionary import Dictionary
lexicon = Dictionary('assets/dictionary.sqlite3')
results = lexicon.lookup('eat', 'en-fr')
forms = lexicon.lookup('mangeais', 'fr-en')
lexicon.close()
```

Mỗi kết quả gồm các chuỗi `word`, `translation`, `pos`, `gender`, `example`, `example_translation`, `source`, `lemma`, `group`, `definition`, `match_kind`. `lemma` luôn là từ tiếng Pháp gốc. `match_kind` là `headword`, `reverse-gloss`, `reverse-translation` hoặc `inflected-form`. DB mở bằng SQLite `mode=ro&immutable=1`; không ghi nhật ký hoặc từ vựng vào DB từ điển.
