# Kiểm tra tiếng Pháp offline

Ứng dụng dùng **Grammalecte 2.3.0**, của Olivier R., tải từ bản Python chính thức:
https://grammalecte.net/zip/Grammalecte-fr-v2.3.0.zip

Mã nguồn, quy tắc và từ điển Graphspell được đóng gói trong `vendor/`.
Không cần Java, Internet, tài khoản hay tải thêm dữ liệu khi mở ứng dụng.
README chính thức trong gói xác nhận **GPL 3**; toàn văn nằm ở `vendor/LICENSE.txt`.
Giữ nguyên các thông báo bản quyền và giấy phép của từng thành phần vendor.

## Phạm vi

- Kiểm tra từ không có trong từ điển và gợi ý chính tả từ dữ liệu Graphspell.
- Phát hiện các quy tắc ngữ pháp, chia động từ, hợp giống/số và một số lỗi dấu câu.
- Trả về vị trí bắt đầu/kết thúc trên nguyên văn; mã giao diện phải đổi sang UTF-16
  bằng `utf16_position` trước khi dùng `QTextCursor`, đặc biệt khi có emoji.
- Đọc nguyên mẫu từ từ điển hình thái; một dạng chia có thể có nhiều nguyên mẫu.
  Ví dụ `suis` có cả `être` và `suivre`; ứng dụng không tự quyết định nghĩa theo ngữ cảnh.
- Nhóm động từ chỉ hiển thị khi dữ liệu xác định được một động từ và nhóm 1/2/3.
  Không suy đoán từ đuôi từ. Ẩn nhóm của `aller` vì phân loại kỹ thuật của nguồn
  khác cách phân nhóm trong bài học; ẩn nhóm trợ động từ `être`/`avoir`.

## Giới hạn

Đây là bộ quy tắc, không phải AI hiểu toàn bộ câu chuyện. Có thể bỏ sót lỗi hoặc
báo nhầm tên riêng, tiếng lóng và từ mới. Gợi ý không đảm bảo đúng với ý định của
người viết. Người dùng phải chọn sửa; không tự động thay nội dung nhật ký.
Đoạn văn được kiểm tra riêng theo xuống dòng nên không phân tích quan hệ xuyên đoạn.
Các thông báo chi tiết của bộ kiểm tra giữ tiếng Pháp gốc.

## Kiểm thử

`tests/test_grammar.py` kiểm tra lỗi chính tả thật, lỗi chia động từ thật, gợi ý,
nguyên mẫu, phân nhóm không suy đoán, vị trí với emoji/CRLF/xuống dòng, văn bản
trống, truyền sai kiểu dữ liệu và truy cập từ nhiều luồng. Kết quả chạy cụ thể
được tổng hợp trong báo cáo kiểm thử chung. Không coi kiểm thử Linux là kiểm thử Windows.
