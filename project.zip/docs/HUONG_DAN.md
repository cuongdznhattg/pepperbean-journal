# Hướng dẫn sử dụng PepperBean Journal

**Hướng dẫn này áp dụng cho bản Windows đã build. Gói mã nguồn bàn giao hiện chưa có EXE.** Cách build tự động nằm trong `BUILD_WINDOWS.md`.

1. Giải nén toàn bộ bản portable, mở thư mục `PepperBeanJournal` rồi nhấp đúp `PepperBeanJournal.exe`. Giữ nguyên thư mục `_internal` cạnh EXE; không chạy ngay từ trong ZIP.
2. Viết nhật ký vào vùng giữa. Ứng dụng tự lưu sau khoảng 0,65 giây ngừng gõ. Xem trạng thái dưới cùng; bấm **Lưu** hoặc **Ctrl+S** để lưu ngay.
3. Bấm ngày ở góc trên để mở lịch. Chọn bài trong thanh bên để đọc và sửa. Ô tìm kiếm nhận nội dung hoặc ngày dạng **2026-11-06**.
4. Tra từ tiếng Anh ở cột phải. Chọn một nghĩa rồi bấm **Chèn từ tiếng Pháp** hoặc **Lưu từ vựng**. Nhấp đúp một từ tiếng Pháp trong bài để tra ngược. Nếu không có kết quả, thử nguyên mẫu; không phải từ nào cũng có trong bộ dữ liệu.
5. Bấm **Check French**. Chọn lỗi trong danh sách dưới bài viết để thấy vị trí và gợi ý. Chọn cách sửa rồi bấm **Áp dụng gợi ý**. Kiểm tra lại sau mỗi lần sửa. Ctrl+Z hoàn tác sửa văn bản trong phiên đang mở.
6. Bấm **Từ vựng** để xem, tìm hoặc xóa từ đã lưu. Từ vựng được lưu chung với dữ liệu nhật ký, không phụ thuộc thư mục EXE.
7. Bấm **Xuất TXT / MD** để xuất bài đang mở. File UTF-8 giữ dấu tiếng Pháp và emoji. Xuất không thay thế chức năng sao lưu toàn bộ dữ liệu.
8. Bấm **Sao lưu dữ liệu** và chọn file `.sqlite3` trên ổ khác để bảo vệ cả nhật ký lẫn từ vựng. **Phục hồi bản sao lưu** thay toàn bộ dữ liệu hiện tại bằng bản đã chọn, sau khi giữ một bản hiện tại trong thư mục `backups`.
9. Bấm **Lịch sử sửa** để xem và lấy lại nội dung cũ của ngày đang mở. Lịch sử được lưu theo lần ghi thành công; không phải lịch sử mọi phím gõ.

## Khi có lỗi lưu

Nếu trạng thái báo **LƯU THẤT BẠI**, nội dung vẫn ở trình soạn thảo. Sao chép ra nơi an toàn, kiểm tra dung lượng trống và quyền ghi, rồi bấm Lưu lại. Ứng dụng chặn đổi ngày hoặc đóng bình thường nếu chưa lưu được. Tắt cưỡng bức tiến trình có thể làm mất phần chưa kịp tự lưu.

Nếu xóa hết bài cũ, tự lưu sẽ tạm dừng và yêu cầu bấm Lưu để xác nhận. Chọn Không thì bài cũ trên đĩa vẫn còn; có thể Ctrl+Z để hoàn tác phần xóa trong trình soạn thảo.

## Dữ liệu nằm ở đâu?

Mở File Explorer, dán `%LOCALAPPDATA%\PepperBeanJournal` vào thanh địa chỉ. Không chỉnh sửa/xóa `journal.sqlite3`, `journal.sqlite3-wal` hoặc `journal.sqlite3-shm` khi ứng dụng đang chạy. Dùng nút Sao lưu để tạo bản chụp độc lập, tránh chép thiếu dữ liệu đang nằm trong WAL.

Sao lưu tự động nằm trong `backups`. Các bản sao này ở cùng máy, nên không bảo vệ được khi ổ đĩa hỏng. Ứng dụng không tự xóa bản sao hay lịch sử sửa. Bạn có thể lưu bản sao ở ổ ngoài bằng giao diện.

Nếu không khởi động được do cơ sở dữ liệu hỏng, ứng dụng giữ nguyên file và báo lỗi; không tự tạo bản rỗng thay thế. Giữ lại toàn bộ thư mục và các bản sao lưu để phục hồi có kiểm soát. Giao diện phục hồi hiện chỉ dùng được sau khi ứng dụng khởi động thành công.

## Hiểu đúng từ điển và bộ kiểm tra

**Mục dịch trực tiếp** đến từ từ điển song ngữ. **Tra ngược định nghĩa** là tìm từ tiếng Pháp qua nghĩa tiếng Anh trong Wiktionary; đọc định nghĩa đầy đủ và nhãn ngữ cảnh trước khi dùng. Dữ liệu có thể chứa từ hiếm, cổ, chuyên ngành hoặc tục được gắn nhãn từ nguồn. Một từ có nhiều nghĩa không đồng nghĩa các nghĩa thay thế được cho nhau.

Thông tin không có nguồn sẽ được bỏ trống. Ví dụ chỉ hiện khi nguồn có, không tự sinh câu. `suis` có thể thuộc cả `être` và `suivre`; chọn nghĩa theo câu.

Grammalecte kiểm tra theo quy tắc. Không phát hiện lỗi không có nghĩa câu chắc chắn đúng. Tin nhắn lỗi chủ yếu bằng tiếng Pháp. Nội dung không được gửi lên mạng.
