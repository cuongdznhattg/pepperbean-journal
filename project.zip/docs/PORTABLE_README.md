# PepperBean Journal — bản portable Windows

File hướng dẫn này được quy trình build đặt ở gốc gói portable sau khi tạo EXE và chạy self-test thành công.

1. Giải nén toàn bộ ZIP, không chạy trong ZIP.
2. Nhấp đúp `PepperBeanJournal.exe`. Giữ nguyên `_internal` bên cạnh.
3. Không cần cài Python, Java hoặc từ điển. Không cần terminal.
4. Hướng dẫn sử dụng nằm ở `docs/HUONG_DAN.md`.

Nhật ký và từ vựng nằm trong `%LOCALAPPDATA%\PepperBeanJournal`, tách khỏi thư mục này. Bấm Sao lưu trước khi cập nhật và lưu bản sao trên ổ khác. Không tự xóa dữ liệu LocalAppData.

`windows-packaged-self-test.json` là kết quả kiểm tra chính bản EXE này. Các báo cáo Linux trong `docs` là bằng chứng ở giai đoạn chuẩn bị mã nguồn, không phải kết quả Windows mới nhất. Build trên Windows Server hoặc máy đã có Python vẫn chưa thay thế thử trên Windows 11 sạch, tài khoản thường, không Python/Java và đã ngắt mạng. Không mặc nhiên coi bản này đã qua kiểm thử máy Windows 11 sạch.

`Source.zip` chứa mã nguồn tương ứng, nguồn từ điển để dựng lại offline, bộ kiểm tra Grammalecte và workflow build. Giấy phép ở `LICENSE`, `THIRD_PARTY.md`, `LICENSES/`. Gói không có API trả phí hoặc thuê bao.
