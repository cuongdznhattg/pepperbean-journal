# Báo cáo kiểm thử — PepperBean Journal 2.0.0rc1

Ngày thực hiện: **06/11/2026**. Môi trường: Linux x86_64, Python 3.12.14, PySide6 6.8.3, SQLite đi kèm Python; giao diện Qt chạy offscreen.

**Chưa có bản EXE Windows. Chưa chạy workflow Windows. Chưa kiểm thử Windows 11 sạch. Chưa đạt điều kiện phát hành Windows hoàn chỉnh.**

## Kết quả thực hiện

- **54 kiểm thử tự động đạt**: 10 lưu trữ, 23 từ điển, 8 Grammalecte, 10 giao diện, 3 khả năng phục hồi/khóa phiên chạy.
- Self-test tích hợp mã nguồn đạt; báo cáo gốc `smoke-linux.json`.
- Đã build PyInstaller 6.16.0 thành chương trình **Linux ELF**, rồi chạy chính chương trình đóng gói qua self-test: đạt; báo cáo `smoke-packaged-linux.json`. Đây không phải Windows EXE, không giao nhầm cho người dùng Windows.
- Bản Linux dùng để kiểm tra có thư viện Python, Qt, dữ liệu từ điển và Grammalecte trong gói. Dung lượng Linux không dùng để khẳng định dung lượng Windows.
- Dựng lại từ điển offline từ nguồn đi kèm cho SHA256 giống hệt trước khi dựng: `19d40c8211c9eb36545596c70eec1f2c105a2bbbb754a41a62bca9a10c1375fe`.
- Kiểm tra ảnh giao diện Qt thực tế ở 1320×850 và 980×650. Đã sửa lỗi các nút bị cắt khi cửa sổ nhỏ bằng bố trí hai hàng. Ảnh minh họa `interface-linux.png`; nội dung nhật ký trong ảnh là dữ liệu thử.

## Đối chiếu 13 yêu cầu

| # | Kiểm thử | Kết quả thực tế |
|---:|---|---|
| 1 | Mở lần đầu | Đạt trên Linux, mã nguồn và bản đóng gói; không tạo bài rỗng khi đọc |
| 2 | Viết và lưu nhật ký | Đạt: tự lưu, lưu tay, Unicode/emoji |
| 3 | Đóng và mở lại | Đạt trên Linux: đóng cửa sổ, đóng kết nối SQLite, tạo lại và mở bài |
| 4 | Nội dung còn nguyên | Đạt so sánh chính xác, gồm dấu tiếng Pháp và emoji |
| 5 | Mở bài cũ | Đạt qua danh sách và ngày |
| 6 | Sửa và lưu bài cũ | Đạt; lưu lịch sử sửa và đổi ngày trước khi debounce xong |
| 7 | Tra English → French | Đạt trên dữ liệu thật; kiểm tra cặp nghĩa cụ thể, không chỉ kiểm tra có kết quả |
| 8 | Nhấp đúp French → English | Đạt sự kiện nhấp đúp Qt trên từ `suis`, có tra từ gốc |
| 9 | Lưu từ vựng | Đạt lưu, tìm, xóa và phục hồi cùng nhật ký |
| 10 | Chính tả/ngữ pháp | Đạt lỗi `pommme` và hòa hợp `Les chats mange`; chọn vị trí, sửa có xác nhận, Unicode UTF-16, bỏ kết quả cũ khi bài đã đổi |
| 11 | Không Internet | Đạt trong kiểm thử chặn socket Python, cả mã nguồn và Linux đóng gói; **chưa thử ngắt mạng vật lý trên Windows** |
| 12 | Windows 11 sạch, không Python/Java | **CHƯA KIỂM THỬ**; môi trường hiện tại không phải Windows, không có máy Windows 11 để chạy |
| 13 | Sao lưu/phục hồi | Đạt SQLite snapshot, dữ liệu/từ vựng/lịch sử; từ chối bản sao sai/hỏng, bảo vệ DB đang mở, có bản sao trước phục hồi |

## Kiểm thử dữ liệu và tình huống lỗi

- Đọc bài không tồn tại không tạo hay ghi đè dữ liệu.
- Tự lưu không xóa trắng bài cũ; cần xác nhận lưu bài trống.
- Lỗi ghi giả lập “disk full”: không đổi ngày, không đóng cửa sổ, giữ văn bản chưa lưu.
- Tiến trình thực ghi xong rồi `os._exit(0)`: mở lại vẫn đọc đúng dữ liệu đã commit trong WAL.
- Tiến trình thực đang trong giao dịch rồi thoát đột ngột: dữ liệu chưa commit bị hoàn tác, bản cũ còn nguyên.
- Khóa một phiên chạy, không mở hai cửa sổ cùng DB qua điểm vào ứng dụng.
- Sao lưu SQLite được kiểm tra, đóng thành file độc lập; không sao chép tùy tiện DB đang có WAL.
- Bản sao không hợp lệ không thay đổi dữ liệu hiện tại; chặn đường dẫn/hardlink trỏ về DB đang mở.
- Xuất văn bản atomic; chặn xuất đè vào DB/tài nguyên ứng dụng.
- Kết quả kiểm tra ngữ pháp được gắn với ngày và nội dung gốc; không áp dụng vào bài đã thay đổi.
- Sau khi đổi chiều từ điển, kết quả cũ bị xóa để tránh chèn nhầm ngôn ngữ.

## Bằng chứng và giới hạn

`pytest-linux.xml` là báo cáo máy đọc được; `smoke-linux.json` và `smoke-packaged-linux.json` ghi nền tảng, bước chạy và trạng thái. Các bài kiểm thử GUI thao tác widget thật nhưng dùng offscreen; chưa có kiểm thử thủ công trên màn hình Windows. Phần dialog chọn file/xác nhận trong test được thay bằng lựa chọn cố định để bài kiểm thử không dừng chờ người bấm.

Thử tạo network namespace để cô lập mạng cấp hệ điều hành không được môi trường cho phép (`Operation not permitted`), nên không ghi nhận là đã ngắt mạng cấp OS. Mã chạy ứng dụng không chứa tải tài nguyên, gọi API hay telemetry; tự kiểm thử chặn các hàm connect ở Python vẫn không chứng minh mọi nền tảng/điều kiện mạng.

Chưa kiểm thử mất điện vật lý, ổ đĩa hỏng, Unicode tên tài khoản Windows, antivirus, SmartScreen, DPI 125–200%, trình đọc màn hình, khối lượng nhật ký rất lớn hoặc khởi động phục hồi từ DB bị hỏng. Không có kiểm định chất lượng ngôn ngữ toàn bộ từ điển hay toàn bộ quy tắc Grammalecte.

## Điều kiện còn thiếu trước phát hành Windows

1. Chạy `Build Windows portable`, lưu log và báo cáo từ chính EXE. Workflow chỉ đóng gói khi kiểm thử đạt.
2. Giải nén ZIP vào máy Windows 11 64-bit sạch, tài khoản thường, không cài Python/Java.
3. Ngắt mạng, mở EXE, thực hiện lại đủ 13 bước trên; kiểm tra mở lịch, font/dấu tiếng Pháp, thay đổi kích thước và đường dẫn LocalAppData.
4. Đo dung lượng gói và RAM/thời gian mở thật. Không dùng số liệu Linux để khẳng định Windows.
5. Chỉ đổi trạng thái thành hoàn thành sau khi ghi nhận các kết quả này.
