# Giới hạn còn tồn tại

1. Chưa có EXE Windows; chưa chạy workflow Windows; chưa kiểm thử Windows 11 sạch, DPI cao, SmartScreen, quyền tài khoản thường và phần mềm chống virus. Bản bàn giao chưa đạt tiêu chí ứng dụng Windows hoàn chỉnh.
2. Các bài kiểm thử hiện chạy trên Linux, Qt offscreen. Có ảnh giao diện thật được render bằng Qt, nhưng không phải ảnh chụp Windows.
3. Kiểm thử offline chặn hàm socket của Python; chưa ngắt mạng vật lý trên máy Windows. Mã ứng dụng không có tải tài nguyên, API, máy chủ hoặc telemetry.
4. English → French gồm 8.799 đầu mục FreeDict trực tiếp và các khóa bổ sung từ tra ngược nghĩa tiếng Anh/FreeDict Pháp–Anh. Con số 87.665 khóa tra không phải 87.665 mục Anh–Pháp đã được biên tập thủ công. Kiểm tra 104 từ thường dùng chỉ đo có kết quả, không đo độ đúng của toàn bộ từ điển.
5. Nhãn nghĩa, giống, từ loại, ví dụ có thể thiếu hoặc sai theo nguồn mở. Nhóm động từ lấy bảo thủ từ Grammalecte; không đoán bằng đuôi từ, không hiện nếu nguồn phân loại không phù hợp/không rõ.
6. Không có dịch Việt–Pháp, dịch cả đoạn, phát âm, AI viết lại, đồng bộ đám mây hoặc nhập tự động nhật ký 1.0.
7. Grammalecte không hiểu mọi ngữ cảnh; có thể bỏ sót hoặc báo nhầm. Gợi ý không tự áp dụng. Bài rất dài có thể kiểm tra chậm; khi đang kiểm tra, đóng cửa sổ sẽ đợi tác vụ hoàn tất sau khi lưu.
8. SQLite và sao lưu không được mã hóa bằng mật khẩu. Quyền truy cập dữ liệu theo tài khoản hệ điều hành. Tự lưu không bảo đảm phần gõ chưa đến thời điểm lưu khi mất điện/tắt cưỡng bức.
9. Sao lưu tự động ở cùng ổ đĩa; không thay thế bản sao ngoài máy. Lịch sử sửa và bản sao không tự dọn nên dung lượng có thể tăng. Phục hồi từ giao diện yêu cầu ứng dụng khởi động được; nếu DB gốc hỏng, cần xử lý giữ nguyên bản hỏng trước khi thay bản sao tốt.
10. Từ điển giới hạn 60 kết quả mỗi lần tra, ưu tiên mục dịch trực tiếp và kết quả chính xác. Một số từ nhiều nghĩa/dạng biến đổi có thể bị cắt bớt kết quả. Không tìm gần đúng hoặc tìm theo một phần từ.
11. Xuất TXT/MD hiện theo từng ngày. Không có cài đặt MSI, cập nhật tự động hoặc chứng thư ký số. Dung lượng Windows 150–350 MB là mục tiêu; chưa đo được vì chưa build Windows.
