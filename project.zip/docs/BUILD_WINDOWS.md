# Tạo PepperBeanJournal.exe trên Windows

**Gói mã nguồn không phải ứng dụng Windows hoàn chỉnh.** Chỉ sau khi build thành công mới có `PepperBeanJournal.exe`. Môi trường Linux nơi chuẩn bị mã nguồn không thể xác nhận chương trình chạy trên Windows 11.

Ứng dụng sau build không cần Internet, Python, Java hoặc tải từ điển riêng. Người build cần Internet để lấy công cụ phát triển; người sử dụng bản portable không cần các công cụ này.

## Cách không cần cài công cụ trên máy: GitHub Actions

Quy trình đã có sẵn trong `.github/workflows/windows.yml`. Đây là quy trình build chưa được thực thi trong phiên chuẩn bị mã nguồn. GitHub là dịch vụ riêng; mức sử dụng miễn phí, hạn mức và khả năng chạy workflow phụ thuộc tài khoản/chính sách của GitHub. Không tự bật dịch vụ có tính phí.

1. Đăng nhập GitHub và tạo một repository trống. Có thể để Private. Không đưa nhật ký, bản sao lưu hoặc dữ liệu cá nhân lên repository.
2. Giải nén gói mã nguồn. Trong repository, dùng **Add file → Upload files** để đưa nội dung thư mục dự án lên. `run.py`, `pepperbean`, `vendor`, `tools`, `tests`, `docs`, `requirements-build.txt` và `PepperBeanJournal.spec` phải nằm ngay tại gốc repository.
3. Tải cả `assets/dictionary_sources` và các file `assets/icon.*`. **Không cần tải `assets/dictionary.sqlite3`**: workflow sẽ tạo lại offline từ nguồn đi kèm, tránh giới hạn dung lượng upload. Mỗi file nguồn compact nhỏ hơn 25 MB tại thời điểm bàn giao. Nếu GitHub báo quá nhiều file, chia thành nhiều lượt upload, giữ nguyên đường dẫn.
4. Đảm bảo file `.github/workflows/windows.yml` cũng có trong repository. Nếu trình chọn file bỏ qua thư mục bắt đầu bằng dấu chấm, dùng **Add file → Create new file**, đặt tên đầy đủ `.github/workflows/windows.yml`, rồi dán nguyên nội dung file cùng tên trong gói mã nguồn.
5. Mở tab **Actions**, cho phép chạy Actions nếu GitHub yêu cầu, chọn **Build Windows portable → Run workflow → Run workflow**.
6. Đợi kết quả. Chỉ dùng bản có trạng thái xanh. Nếu trạng thái đỏ, tải `windows-test-evidence` nếu có và gửi log lỗi để sửa; không bỏ qua kiểm thử để lấy bản phát hành.
7. Mở lượt chạy xanh, tại **Artifacts**, tải `PepperBeanJournal-Windows-x64`. GitHub bọc artifact trong một ZIP ngoài; giải nén để lấy `PepperBeanJournal-Windows-x64.zip`, rồi giải nén ZIP này.
8. Trong thư mục `PepperBeanJournal`, nhấp đúp **PepperBeanJournal.exe**. Giữ nguyên thư mục `_internal` bên cạnh. Không chỉ chép riêng file EXE và không chạy trực tiếp từ bên trong ZIP.

Workflow không tự công khai repository, không tạo release và không gửi dữ liệu nhật ký. Artifact có thời hạn lưu 14 ngày theo cấu hình; tải về trước khi hết hạn.

## Người phát triển build trực tiếp trên Windows

Điều kiện: Windows 64-bit, Python **3.12 64-bit** trên máy build. Đây là điều kiện của người build, không áp dụng cho người sử dụng ứng dụng đã đóng gói.

Mở PowerShell trong thư mục dự án, chạy:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\build_windows.ps1
```

Script chỉ tạo môi trường riêng `.venv-build` trong dự án, không cần quyền Administrator. Nếu máy build dùng `py` launcher mà không có lệnh `python`, người phát triển cần chọn đường dẫn `python.exe` 3.12 qua tham số `-Python`. Script không tải Python hoặc Java cho ứng dụng khi khởi động.

Các bước tự động:

1. Xác nhận Python 3.12, kiến trúc 64-bit và hệ điều hành Windows.
2. Cài các phiên bản công cụ cố định trong `requirements-build.txt` vào `.venv-build`.
3. Kiểm tra SHA256 nguồn từ điển và tạo lại SQLite bằng `tools/build_dictionary.py`, không gọi mạng.
4. Chạy toàn bộ `tests`, ghi `release/unit-tests.xml`.
5. Đóng gói PyInstaller dạng **onedir**, giữ thư viện Qt dạng file riêng và đóng gói dữ liệu Grammalecte.
6. Chạy chính EXE vừa tạo với `--self-test --report ...`. Chỉ tiếp tục khi tiến trình trả exit code 0 và báo cáo có `passed: true`.
7. Đính kèm tài liệu, giấy phép và `Source.zip` chứa mã nguồn tương ứng, gồm nguồn từ điển compact và mã Grammalecte. Đóng ZIP portable và in SHA256.

Kết quả: `release/PepperBeanJournal-Windows-x64.zip`. Bản portable không cần cài đặt và không cần quyền Administrator. Nhật ký thật được lưu ở `%LOCALAPPDATA%\PepperBeanJournal`, không nằm trong thư mục EXE; thay thư mục ứng dụng khi cập nhật không tự xóa dữ liệu.

## Những gì workflow chứng minh và chưa chứng minh

- Runner `windows-2025` là **Windows Server**, không phải máy Windows 11 sạch.
- Kiểm thử Qt dùng nền tảng offscreen: xác nhận logic giao diện và tích hợp, chưa chứng minh phông chữ, thao tác chuột, lịch, màn hình DPI cao trên Windows 11 thật.
- Self-test chạy từ EXE đã đóng gói, kiểm tra dữ liệu và các thành phần offline có sẵn. Chặn socket ở cấp Python trong bài kiểm thử không tương đương thử trên máy đã ngắt mạng vật lý.
- Runner có cài Python cho build. Việc EXE chạy ở runner không đủ chứng minh không phụ thuộc phần mềm ngoài trên mọi máy sạch.
- Chưa ký mã số. Windows có thể hiện cảnh báo ứng dụng chưa được nhận diện; không tắt antivirus để chạy. Kiểm tra nguồn gói, SHA256 và kết quả kiểm thử trước khi quyết định mở.
- Dung lượng thật chỉ xác định sau build Windows, không suy ra từ dung lượng mã nguồn hay bản Linux.

Trước khi coi là phát hành hoàn tất, cần thử bản ZIP trên Windows 11 64-bit sạch, tài khoản thường, không cài Python/Java, ngắt Internet; thực hiện đầy đủ các bước trong báo cáo kiểm thử, đặc biệt lưu–đóng–mở lại, tra hai chiều, sửa lỗi, sao lưu–phục hồi. Ghi kết quả thực tế, không đổi “chưa kiểm thử” thành “đạt” chỉ vì workflow xanh.
