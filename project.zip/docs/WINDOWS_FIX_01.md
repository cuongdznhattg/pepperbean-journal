# Sửa lỗi Windows lần 1 — 06/11/2026

Ảnh log GitHub Actions do người dùng cung cấp cho thấy 53 kiểm thử đạt, một kiểm thử thất bại: test_bad_restore_preserves_current_data, PermissionError WinError 32 trên bad.sqlite3. Quy trình dừng đúng tại kiểm thử, chưa tạo EXE.

Đối chiếu mã: bài kiểm thử tạo một SQLite giả bằng `with sqlite3.connect(...)`. Context manager này xử lý commit/rollback nhưng không đóng kết nối. Khi dọn thư mục tạm, Windows không cho xóa file còn mở.

Sửa: dùng contextlib.closing bao quanh kết nối giả, giữ context giao dịch bên trong; thêm thao tác xóa file ngay sau khi kiểm tra bản sao bị từ chối để kiểm chứng việc nhả file. Không bỏ qua kiểm thử, không đổi điều kiện phát hành và không thay đổi logic phục hồi dữ liệu của ứng dụng.

Đã chạy lại toàn bộ 54 kiểm thử trên Linux: đạt. Bản sửa CHƯA được chạy lại trên Windows; cần GitHub Actions chạy từ commit chứa project.zip mới. Không dùng Re-run jobs của lượt cũ vì lượt đó vẫn dùng commit cũ.
