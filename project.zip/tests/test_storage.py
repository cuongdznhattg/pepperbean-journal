import sqlite3
from contextlib import closing
import os
import tempfile
import unittest
from pathlib import Path

from pepperbean.storage import Store, atomic_write


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "data" / "journal.sqlite3"
        self.store = Store(self.path)

    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()

    def test_first_open_and_empty_reads_do_not_overwrite(self):
        self.assertEqual(self.store.get_entry("2026-11-06"), "")
        self.assertEqual(self.store.list_entries(), [])
        self.store.save_entry("2026-11-06", "")
        self.assertEqual(self.store.list_entries(), [])
        self.store.save_entry("2026-11-05", "J’ai étudié le français. 😀")
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(self.store.get_entry("2026-11-06"), "")
        self.assertEqual(self.store.get_entry("2026-11-05"), "J’ai étudié le français. 😀")

    def test_edit_old_entry_search_and_revision(self):
        self.store.save_entry("2026-10-01", "ancienne phrase")
        self.store.save_entry("2026-11-06", "aujourd’hui")
        self.store.save_entry("2026-10-01", "École française")
        self.assertEqual(self.store.list_entries("éCOLE")[0]["day"], "2026-10-01")
        self.assertEqual(len(self.store.list_entries("2026-11")), 1)
        self.assertEqual(self.store.conn.execute("SELECT body FROM entry_revisions").fetchone()[0], "ancienne phrase")
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(self.store.get_entry("2026-10-01"), "École française")

    def test_backup_restore_including_vocab_and_recovery_backup(self):
        self.store.save_entry("2026-11-06", "Bonjour !")
        record = {"word": "école", "meaning": "school", "examples": ["Mon école."]}
        self.store.vocab_add(record)
        backup = Path(self.tmp.name) / "backup.sqlite3"
        self.store.backup(backup)
        self.store.save_entry("2026-11-06", "Texte récent")
        self.store.vocab_delete(self.store.vocab_list()[0]["id"])
        self.store.restore(backup)
        self.assertEqual(self.store.get_entry("2026-11-06"), "Bonjour !")
        self.assertEqual(self.store.vocab_list()[0]["meaning"], "school")
        recovery = Store(self.store.last_restore_backup)
        self.assertEqual(recovery.get_entry("2026-11-06"), "Texte récent")
        recovery.close()
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(self.store.get_entry("2026-11-06"), "Bonjour !")

    def test_bad_restore_preserves_current_data(self):
        self.store.save_entry("2026-11-06", "Ne pas perdre.")
        bad = Path(self.tmp.name) / "bad.sqlite3"
        bad.write_bytes(b"not a sqlite database")
        with self.assertRaises(sqlite3.DatabaseError):
            self.store.restore(bad)
        self.assertEqual(self.store.get_entry("2026-11-06"), "Ne pas perdre.")
        bad.unlink()
        # sqlite3 connection context managers commit/rollback but DO NOT close.
        # Explicit closing is required before Windows can remove the test file.
        with closing(sqlite3.connect(bad)) as connection:
            with connection:
                connection.execute("CREATE TABLE unrelated(x)")
        with self.assertRaises(ValueError):
            self.store.restore(bad)
        self.assertEqual(self.store.get_entry("2026-11-06"), "Ne pas perdre.")
        # Also verify rejected backups release their handle before cleanup.
        bad.unlink()
        with self.assertRaises(ValueError):
            self.store.backup(self.path)

    def test_vocab_duplicate_search_delete_persist(self):
        record = {"word": "manger", "meaning": "eat", "direction": "fr-en"}
        first = self.store.vocab_add(record)
        self.assertEqual(self.store.vocab_add(record), first)
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(len(self.store.vocab_list("EAT")), 1)
        self.store.vocab_delete(first)
        self.assertEqual(self.store.vocab_list(), [])

    def test_invalid_dates_and_atomic_export(self):
        with self.assertRaises(ValueError):
            self.store.save_entry("2026-02-31", "x")
        target = Path(self.tmp.name) / "export.md"
        atomic_write(target, "# Journal\nÉté 😀\n")
        self.assertEqual(target.read_text("utf-8"), "# Journal\nÉté 😀\n")
        atomic_write(target, "Remplacement")
        self.assertEqual(target.read_text("utf-8"), "Remplacement")

    def test_write_failure_is_atomic_and_original_text_survives(self):
        self.store.save_entry("2026-11-06", "Original")
        # Real SQLite write denial, not a mocked implementation.
        self.store.conn.execute("PRAGMA query_only=ON")
        with self.assertRaises(sqlite3.OperationalError):
            self.store.save_entry("2026-11-06", "Replacement")
        self.store.conn.execute("PRAGMA query_only=OFF")
        self.assertEqual(self.store.get_entry("2026-11-06"), "Original")
        self.assertEqual(self.store.conn.execute("SELECT count(*) FROM entry_revisions").fetchone()[0], 0)

    def test_revision_history_is_ordered_scoped_and_survives_restore(self):
        self.store.save_entry("2026-11-05", "First")
        self.store.save_entry("2026-11-05", "Second")
        self.store.save_entry("2026-11-05", "Third")
        self.store.save_entry("2026-11-06", "Other date")
        self.store.save_entry("2026-11-06", "Updated other date")
        revisions = self.store.list_revisions("2026-11-05")
        self.assertEqual([row["body"] for row in revisions], ["Second", "First"])
        self.assertTrue(all(set(row) == {"id", "body", "saved_at"} for row in revisions))
        self.assertEqual(self.store.list_revisions("2026-10-01"), [])
        backup = Path(self.tmp.name) / "revisions.sqlite3"
        self.store.backup(backup)
        self.store.save_entry("2026-11-05", "Fourth")
        self.store.restore(backup)
        self.assertEqual(self.store.list_revisions("2026-11-05"), revisions)

    def test_hardlink_and_sidecar_paths_are_rejected(self):
        self.store.save_entry("2026-11-06", "Safe original")
        alias = Path(self.tmp.name) / "alias.sqlite3"
        os.link(self.path, alias)
        with self.assertRaises(ValueError):
            self.store.backup(alias)
        with self.assertRaises(ValueError):
            self.store.restore(alias)
        for suffix in ("-wal", "-shm", "-journal"):
            with self.assertRaises(ValueError):
                self.store.backup(Path(str(self.path) + suffix))
        foreign = Path(self.tmp.name) / "foreign.sqlite3"
        foreign.write_bytes(b"original foreign content")
        sidecar = Path(str(foreign) + "-wal")
        sidecar.write_bytes(b"foreign sidecar")
        with self.assertRaises(ValueError):
            self.store.backup(foreign)
        with self.assertRaises(ValueError):
            self.store.restore(foreign)
        self.assertEqual(foreign.read_bytes(), b"original foreign content")
        self.assertEqual(sidecar.read_bytes(), b"foreign sidecar")
        self.assertEqual(self.store.get_entry("2026-11-06"), "Safe original")

    def test_backup_is_standalone_and_has_no_sidecars(self):
        self.store.save_entry("2026-11-06", "WAL content must be copied")
        backup = Path(self.tmp.name) / "standalone.sqlite3"
        self.store.backup(backup)
        for suffix in ("-wal", "-shm", "-journal"):
            self.assertFalse(Path(str(backup) + suffix).exists())
        connection = sqlite3.connect(backup.as_uri() + "?mode=ro", uri=True)
        try:
            self.assertEqual(connection.execute("PRAGMA journal_mode").fetchone()[0], "delete")
            self.assertEqual(connection.execute("SELECT body FROM entries").fetchone()[0], "WAL content must be copied")
        finally:
            connection.close()


if __name__ == "__main__":
    unittest.main()
