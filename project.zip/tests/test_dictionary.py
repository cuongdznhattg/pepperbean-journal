from pathlib import Path
import sqlite3
import unicodedata
import pytest
from pepperbean.dictionary import Dictionary

DB=Path(__file__).resolve().parents[1]/'assets'/'dictionary.sqlite3'

@pytest.fixture
def dictionary():
    db=Dictionary(DB)
    yield db
    db.close()

@pytest.mark.parametrize('english,french',[
    ('house','maison'),('eat','manger'),('school','école'),('computer','ordinateur'),
    ('happy','heureux'),('learn','apprendre'),('actuary','actuaire'),
    ('insurance','assurance'),('breakfast','petit déjeuner'),('work','travailler'),
])
def test_real_english_translation(dictionary,english,french):
    results=dictionary.lookup(english)
    assert any(r['translation']==french for r in results)
    assert all(r['source'] for r in results)

@pytest.mark.parametrize('form,lemma',[
    ('mangeais','manger'),('suis','être'),('suis','suivre'),('allons','aller'),
    ('pris','prendre'),('maisons','maison'),('heureuse','heureux'),
])
def test_real_inflection(dictionary,form,lemma):
    assert any(r['lemma']==lemma and r['match_kind']=='inflected-form' for r in dictionary.lookup(form,'fr-en'))


def test_nfc_case_and_accents(dictionary):
    assert dictionary.lookup('ÉCOLE','fr-en')==dictionary.lookup(unicodedata.normalize('NFD','école'),'fr-en')
    assert dictionary.lookup('  HOUSE  ')==dictionary.lookup('house')


def test_unknown_not_invented_and_injection_safe(dictionary):
    assert dictionary.lookup('qzxqzxnonexistent')==[]
    assert dictionary.lookup("'; DROP TABLE entries; --")==[]
    assert dictionary.lookup('house')
    assert dictionary.lookup('')==[]


def test_read_only(dictionary):
    with pytest.raises(sqlite3.OperationalError):
        dictionary.db.execute("DELETE FROM entries")


def test_real_examples_metadata_and_conservative_reverse(dictionary):
    eat=next(r for r in dictionary.lookup('eat') if r['translation']=='manger')
    assert eat['example'] and eat['example_translation']
    house=next(r for r in dictionary.lookup('house') if r['translation']=='maison')
    assert house['gender']=='feminine'
    assert all(r['translation']!='demi-pension' for r in dictionary.lookup('breakfast'))
    assert all(isinstance(v,str) for v in eat.values())
    assert eat['group']=='' # Never guess group from word ending.


def test_coverage_not_demo(dictionary):
    stats=dictionary.stats()
    assert int(stats['en-fr_keys'])>80000
    assert int(stats['fr-en_keys'])>90000
    assert int(stats['distinct_inflected_forms'])>350000
    assert dictionary.db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'


def test_bad_direction_and_missing_database(dictionary,tmp_path):
    with pytest.raises(ValueError):dictionary.lookup('hello','vi-fr')
    with pytest.raises(FileNotFoundError):Dictionary(tmp_path/'missing.db')
    assert not (tmp_path/'missing.db').exists()
