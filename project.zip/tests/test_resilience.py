"""Committed WAL recovery and interrupted transaction safety using real processes."""
import os
from pathlib import Path
import subprocess
import sys
from PySide6.QtCore import QLockFile
from pepperbean.storage import Store

ROOT = Path(__file__).resolve().parents[1]


def test_committed_write_survives_abrupt_exit(tmp_path):
    path = tmp_path / 'journal.sqlite3'
    code = '''import sys, os
from pepperbean.storage import Store
s=Store(sys.argv[1])
s.save_entry('2026-01-01', 'Été français 😀')
os._exit(0)
'''
    process = subprocess.run([sys.executable, '-c', code, str(path)], cwd=ROOT, timeout=15)
    assert process.returncode == 0
    store = Store(path)
    assert store.get_entry('2026-01-01') == 'Été français 😀'
    store.close()


def test_incomplete_transaction_rolls_back_after_process_exit(tmp_path):
    path = tmp_path / 'journal.sqlite3'
    store = Store(path)
    store.save_entry('2026-01-01', 'Committed entry')
    store.close()
    code = '''import sys, os
from pepperbean.storage import Store
s=Store(sys.argv[1])
s.conn.execute('BEGIN IMMEDIATE')
s.conn.execute("UPDATE entries SET body='Incomplete write'")
os._exit(0)
'''
    process = subprocess.run([sys.executable, '-c', code, str(path)], cwd=ROOT, timeout=15)
    assert process.returncode == 0
    store = Store(path)
    assert store.get_entry('2026-01-01') == 'Committed entry'
    store.close()


def test_single_instance_lock(tmp_path):
    first = QLockFile(str(tmp_path / 'journal.lock'))
    second = QLockFile(str(tmp_path / 'journal.lock'))
    first.setStaleLockTime(0)
    second.setStaleLockTime(0)
    assert first.tryLock(0)
    assert not second.tryLock(0)
    first.unlock()
    assert second.tryLock(0)
    second.unlock()
