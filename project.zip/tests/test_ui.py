import socket
from pathlib import Path
import pytest
from PySide6.QtCore import Qt, QDate, QPoint
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QMessageBox, QFileDialog
from PySide6.QtTest import QTest

from pepperbean.storage import Store
from pepperbean.dictionary import Dictionary
from pepperbean.grammar import FrenchChecker
from pepperbean.paths import ASSETS
from pepperbean.ui import MainWindow, utf16_position

@pytest.fixture
def window(qtbot, tmp_path, monkeypatch):
    def blocked(*args, **kwargs):
        raise AssertionError('Unexpected network')
    monkeypatch.setattr(socket.socket, 'connect', blocked)
    monkeypatch.setattr(socket.socket, 'connect_ex', blocked)
    monkeypatch.setattr(socket, 'create_connection', blocked)
    store = Store(tmp_path / 'journal.sqlite3')
    dictionary = Dictionary(ASSETS / 'dictionary.sqlite3')
    win = MainWindow(store, dictionary)
    qtbot.addWidget(win)
    win.show()
    yield win
    win.timer.stop()
    if win.worker and win.worker.isRunning():
        win.worker.wait(20000)
    win.dirty = False
    win.close()
    store.close()
    dictionary.close()


def test_initial_autosave_reopen_old_entry(qtbot, window):
    w = window
    day = w.current_day
    assert w.store.list_entries() == []
    w.editor.setPlainText('😀 Bonjour, j’ai étudié le français.')
    qtbot.waitUntil(lambda: not w.dirty, timeout=3000)
    assert w.store.get_entry(day) == w.editor.toPlainText()
    w.date_edit.setDate(QDate(2020, 2, 29))
    assert w.editor.toPlainText() == ''
    w.editor.setPlainText('Une journée passée.')
    # Change immediately before the debounce fires: previous day is flushed.
    w.date_edit.setDate(QDate.fromString(day, 'yyyy-MM-dd'))
    assert w.store.get_entry('2020-02-29') == 'Une journée passée.'
    w.history_query.setText('passée')
    assert w.entry_list.count() == 1
    w.open_entry(w.entry_list.item(0))
    assert w.current_day == '2020-02-29'
    w.editor.appendPlainText('Une nouvelle phrase.')
    w.save_current()
    assert len(w.store.list_revisions('2020-02-29')) == 1


def test_no_empty_overwrite_and_cancel_navigation(window, monkeypatch):
    w = window
    w.editor.setPlainText('Ne pas perdre ce texte.')
    assert w.save_current()
    day = w.current_day
    w.editor.clear()
    assert not w.save_current(automatic=True)
    assert w.store.get_entry(day) == 'Ne pas perdre ce texte.'
    monkeypatch.setattr(QMessageBox, 'question', lambda *a, **k: QMessageBox.StandardButton.No)
    w.date_edit.setDate(QDate(2020, 1, 1))
    assert w.current_day == day
    assert w.date_edit.date().toString('yyyy-MM-dd') == day
    assert w.dirty


def test_save_failure_blocks_close_and_date(window, monkeypatch):
    w = window
    w.editor.setPlainText('Texte important.')
    monkeypatch.setattr(QMessageBox, 'critical', lambda *a, **k: None)
    def fail(*a): raise OSError('Disk full')
    monkeypatch.setattr(w.store, 'save_entry', fail)
    day = w.current_day
    w.date_edit.setDate(QDate(2021, 1, 1))
    assert w.current_day == day
    assert w.editor.toPlainText() == 'Texte important.'
    assert not w.close()
    assert w.dirty


def test_dictionary_double_click_vocabulary_and_insert(qtbot, window, monkeypatch):
    w = window
    w.word_query.setText('apple')
    w.lookup()
    assert any('pomme' in r['translation'] for r in w.matches)
    w.results.setCurrentRow(next(i for i,r in enumerate(w.matches) if 'pomme' in r['translation']))
    w.insert_word()
    assert 'pomme' in w.editor.toPlainText()
    w.save_word()
    w.show_vocab()
    assert w.vocab_list.count() == 1
    w.vocab_query.setText('pomme')
    assert w.vocab_list.count() == 1
    w.pages.setCurrentIndex(0)
    w.editor.setPlainText('Je suis heureux.')
    cursor = w.editor.textCursor()
    cursor.setPosition(5)
    w.editor.setTextCursor(cursor)
    pos = w.editor.cursorRect(cursor).center()
    with qtbot.waitSignal(w.editor.word_lookup, timeout=2000) as signal:
        qtbot.mouseDClick(w.editor.viewport(), Qt.MouseButton.LeftButton, pos=pos)
    assert signal.args[0] == 'suis'
    assert w.direction.currentData() == 'fr-en'
    assert w.matches
    w.show_vocab()
    monkeypatch.setattr(QMessageBox, 'question', lambda *a, **k: QMessageBox.StandardButton.Yes)
    w.delete_vocab()
    assert not w.store.vocab_list()


def test_grammar_worker_and_utf16_correction(qtbot, window):
    w = window
    w.editor.setPlainText('😀 Bonjour.\nJe mange une pommme.')
    w.check_french()
    qtbot.waitUntil(lambda: w.check_button.isEnabled(), timeout=10000)
    idx = next(i for i in range(w.error_list.count()) if 'pommme' in w.error_list.item(i).text())
    w.error_list.setCurrentRow(idx)
    assert w.editor.textCursor().selectedText() == 'pommme'
    w.suggestions.setCurrentIndex(w.suggestions.findText('pomme'))
    w.apply_correction()
    assert w.editor.toPlainText() == '😀 Bonjour.\nJe mange une pomme.'
    assert w.error_list.count() == 0
    assert w.editor.document().isUndoAvailable()


def test_stale_checker_results_not_applied(window):
    w = window
    old = 'Une pommme.'
    errors = w.checker.check(old)
    w.editor.setPlainText('Une autre phrase.')
    w.accept_checks(errors, old, w.current_day)
    assert w.error_list.count() == 0
    w.editor.setPlainText(old)
    w.accept_checks(errors, old, '1900-01-01')
    assert w.error_list.count() == 0


def test_export_backup_restore_ui(window, tmp_path, monkeypatch):
    w = window
    original = 'Une journée très agréable. 😀'
    w.editor.setPlainText(original)
    export = tmp_path / 'entry.md'
    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *a, **k: (str(export), 'Markdown (*.md)'))
    w.export_entry()
    assert export.read_text(encoding='utf8') == '# ' + w.current_day + '\n\n' + original
    backup = tmp_path / 'snapshot.sqlite3'
    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *a, **k: (str(backup), ''))
    w.backup()
    w.editor.setPlainText('Une modification.')
    w.save_current()
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *a, **k: (str(backup), ''))
    monkeypatch.setattr(QMessageBox, 'question', lambda *a, **k: QMessageBox.StandardButton.Yes)
    w.restore()
    assert w.editor.toPlainText() == original
    assert w.store.last_restore_backup.exists()


def test_export_protects_database(window):
    with pytest.raises(ValueError):
        window.safe_destination(window.store.path)
    with pytest.raises(ValueError):
        window.safe_destination(ASSETS / 'dictionary.sqlite3')


def test_close_flushes_pending_save(window):
    w = window
    w.editor.setPlainText('Fermer immédiatement, sans perdre le texte.')
    day = w.current_day
    assert w.close()
    assert w.store.get_entry(day) == 'Fermer immédiatement, sans perdre le texte.'


def test_switch_dictionary_direction_clears_previous_results(window):
    window.word_query.setText('apple')
    window.lookup()
    assert window.matches and window.insert_button.isEnabled()
    window.direction.setCurrentIndex(1)
    assert not window.matches
    assert not window.insert_button.isEnabled()
