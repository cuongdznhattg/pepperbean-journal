from concurrent.futures import ThreadPoolExecutor

import pytest

from pepperbean.grammar import FrenchChecker, utf16_position


@pytest.fixture(scope="module")
def checker():
    return FrenchChecker()


def test_spelling_and_real_suggestion(checker):
    text = "Je mange une pommme."
    errors = checker.check(text)
    matches = [e for e in errors if text[e["start"]:e["end"]] == "pommme"]
    assert matches
    assert matches[0]["kind"] == "spelling"
    assert "pomme" in matches[0]["suggestions"]


def test_grammar_agreement(checker):
    text = "Les chats mange."
    errors = checker.check(text)
    assert any(e["kind"] == "grammar" and "mangent" in e["suggestions"] for e in errors)


def test_emoji_crlf_and_multiple_paragraph_offsets(checker):
    text = "😀 Bonjour.\r\n\nJe suis fatiguer.\nJe mange une pommme."
    errors = checker.check(text)
    for word in ("fatiguer", "pommme"):
        assert any(e["start"] == text.index(word) and text[e["start"]:e["end"]] == word for e in errors)
    assert utf16_position(text, text.index("fatiguer")) == text.index("fatiguer") + 1


def test_lemmas_preserve_ambiguity(checker):
    assert {"être", "suivre"} <= set(checker.lemmas("suis"))
    assert "manger" in checker.lemmas("mangé")
    assert checker.lemmas("zzzzzzqqq") == []


def test_verb_groups_do_not_guess_from_suffix(checker):
    assert checker.verb_group("mangé") == "1"
    assert checker.verb_group("finir") == "2"
    assert checker.verb_group("prendre") == "3"
    assert checker.verb_group("aller") == ""
    assert checker.verb_group("être") == ""
    assert checker.verb_group("zzzzzzqqq") == ""


def test_empty_and_known_correct_sentence(checker):
    assert checker.check("") == []
    assert checker.check("\r\n\n") == []
    assert checker.check("Je mange une pomme.") == []


def test_shared_engine_serializes_background_work(checker):
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(checker.check, ["Les chats mange."] * 8))
    assert all(result == results[0] for result in results)


def test_bad_input_is_not_reported_as_clean(checker):
    with pytest.raises(TypeError):
        checker.check(None)
    with pytest.raises(ValueError):
        utf16_position("abc", 4)
