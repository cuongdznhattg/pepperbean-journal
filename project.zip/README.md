# PepperBean Journal 2.0 — bản mã nguồn có dữ liệu offline

**Trạng thái bàn giao: ứng viên phát hành, CHƯA có file Windows EXE.**

Ứng dụng đã được viết mới và chạy kiểm thử trên Linux. Gói này chứa mã nguồn, cơ sở dữ liệu từ điển thật, bộ kiểm tra tiếng Pháp Grammalecte, kiểm thử và quy trình build Windows tự động. Đây không phải bản portable Windows có thể nhấp đúp chạy ngay. Không sử dụng mã PepperBean Journal 1.0.

## Đọc gì trước?

- [Hướng dẫn dùng ứng dụng](docs/HUONG_DAN.md).
- [Cách tạo EXE bằng GitHub Actions, không cài Python/Java trên máy của bạn](docs/BUILD_WINDOWS.md).
- [Báo cáo kiểm thử và 13 tiêu chí](docs/TEST_REPORT.md).
- [Nguồn từ điển, độ bao phủ, phương pháp và giấy phép](docs/DICTIONARY.md).
- [Giới hạn bộ kiểm tra tiếng Pháp](docs/GRAMMAR.md).
- [Các giới hạn còn tồn tại](docs/LIMITATIONS.md).

## Những chức năng đã triển khai

- Giao diện PySide6: nền kem, xanh pastel, chọn ngày bằng lịch, viết và xem/sửa bài cũ ngay trong ứng dụng.
- SQLite theo người dùng; tự lưu sau 650 ms ngừng gõ, nút Lưu/Ctrl+S, lưu trước khi đổi ngày hoặc đóng cửa sổ.
- Bài trống lúc khởi động không ghi đè bài cũ. Xóa toàn bộ nội dung cần xác nhận khi lưu.
- Tìm ngày/nội dung; xuất UTF-8 TXT và Markdown; lịch sử sửa từng bài.
- Sao lưu gồm nhật ký, lịch sử sửa và từ vựng; phục hồi có kiểm tra cấu trúc và bản sao trước phục hồi. Sao lưu tự động vào lần mở đầu tiên mỗi ngày nếu đã có dữ liệu.
- Từ điển offline FreeDict + Wiktionary/Kaikki: tra hai chiều, nhận diện dạng biến đổi, giới tính từ/ngữ cảnh/ví dụ khi nguồn có dữ liệu.
- Nhấp đúp từ trong bài để tra French → English; chèn từ tiếng Pháp; lưu/tìm/xóa từ vựng.
- Check French bằng Grammalecte 2.3.0 offline. Hiển thị dòng/vị trí và gợi ý; chỉ sửa khi bạn bấm áp dụng.
- Không API, không tài khoản, không quảng cáo, không tải dữ liệu hoặc cập nhật qua mạng khi chạy.

## Cấu trúc bàn giao

`run.py` là điểm vào cho người phát triển. `pepperbean/` là mã ứng dụng mới. `assets/dictionary.sqlite3` là từ điển đã xử lý; `assets/dictionary_sources/` là nguồn đủ để tạo lại từ điển mà không cần mạng. `vendor/` chứa mã/dữ liệu Grammalecte nguyên gốc. `tools/build_windows.ps1`, `PepperBeanJournal.spec` và `.github/workflows/windows.yml` tạo bản portable Windows khi chạy trong môi trường build Windows.

Người dùng bản portable đã build không cần Python, Java hoặc terminal. Người build mã nguồn cần công cụ phát triển, hoặc dùng workflow trên GitHub. Mã nguồn không tự biến thành EXE chỉ bằng đổi đuôi file.

## Lưu dữ liệu và cập nhật

Trên Windows: `%LOCALAPPDATA%\PepperBeanJournal\journal.sqlite3`. Không lưu nhật ký trong thư mục tải về. Khi cập nhật, thoát ứng dụng, sao lưu và thay thư mục chương trình; không xóa thư mục dữ liệu người dùng. Không có cơ chế hạ cấp dữ liệu tự động. Bản 2.0 không tự nhập dữ liệu 1.0.

Mã ứng dụng mới: GPL-3.0-or-later; nguồn dữ liệu và thành phần bên thứ ba giữ giấy phép riêng trong `THIRD_PARTY.md`, `LICENSES/`, `vendor/` và `assets/dictionary_sources/`.
